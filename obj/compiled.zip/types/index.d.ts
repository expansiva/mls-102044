declare module "_102044_/l1/repairBay/layer_1_external/inventoryAdjustmentCommandLog.defs" {
    export const inventoryAdjustmentCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryAdjustmentCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryAdjustmentCommandLog";
                readonly tableName: "inventory_adjustment_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Ajuste de Estoque";
                readonly purpose: "Registrar comandos de ajuste e baixa de estoque para auditoria e alertas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryAdjustmentCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventory_adjustment_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de ajuste de estoque.";
                }, {
                    readonly name: "command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do comando de ajuste.";
                }, {
                    readonly name: "inventory_stock_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao estoque ajustado.";
                }, {
                    readonly name: "part_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à peça ajustada.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada ao ajuste, quando aplicável.";
                }, {
                    readonly name: "command_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Tipo do comando (entrada, saída, correção, baixa).";
                }, {
                    readonly name: "quantity_delta";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly description: "Variação aplicada ao estoque.";
                }, {
                    readonly name: "previous_quantity";
                    readonly type: "decimal";
                    readonly nullable: true;
                    readonly description: "Quantidade antes do ajuste.";
                }, {
                    readonly name: "new_quantity";
                    readonly type: "decimal";
                    readonly nullable: true;
                    readonly description: "Quantidade após o ajuste.";
                }, {
                    readonly name: "reason_code";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Motivo do ajuste para auditoria.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do comando (registrado, aplicado, revertido, falhou).";
                }, {
                    readonly name: "actor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do usuário que executou o ajuste.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou o ajuste.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do evento de ajuste.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do log.";
                }];
                readonly primaryKey: readonly ["inventory_adjustment_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventory_stock_id";
                    readonly targetEntity: "InventoryStock";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Estoque ajustado vinculado ao log.";
                }, {
                    readonly fieldName: "part_id";
                    readonly targetEntity: "Part";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Peça ajustada para consultas e alertas.";
                }, {
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular ajustes originados por ordens de serviço.";
                }, {
                    readonly fieldName: "command_id";
                    readonly targetEntity: "InventoryAdjustmentCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vínculo com o comando de ajuste registrado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_adjustment_log_command";
                    readonly columns: readonly ["command_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por comando e auditoria.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_stock";
                    readonly columns: readonly ["inventory_stock_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por estoque e período para alertas.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_part";
                    readonly columns: readonly ["part_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por peça e período.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_status";
                    readonly columns: readonly ["status", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Monitorar falhas e reversões.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear ajustes associados à OS.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payload completo do comando e contexto operacional.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["inventoryAdjustmentVolume", "inventoryAdjustmentFailures"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryAdjustmentCommandLog.defs.ts";
                readonly exportName: "inventoryAdjustmentCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryAdjustmentCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/inventoryMetrics.defs" {
    export const inventoryMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "inventoryMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "inventoryMetrics";
                readonly tableName: "inventory_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Estoque";
                readonly purpose: "Monitorar níveis de estoque, alertas de reposição e movimentações.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data e hora do evento de estoque.";
                }, {
                    readonly name: "part_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da peça relacionada.";
                }, {
                    readonly name: "command_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Tipo de movimentação de estoque.";
                }, {
                    readonly name: "is_low_stock";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly default: false;
                    readonly description: "Indicador de estoque abaixo do mínimo.";
                }, {
                    readonly name: "stock_level";
                    readonly type: "numeric(12,2)";
                    readonly nullable: true;
                    readonly description: "Nível atual de estoque.";
                }, {
                    readonly name: "low_stock_count";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly default: 0;
                    readonly description: "Contagem de itens com estoque baixo no evento.";
                }, {
                    readonly name: "adjustment_volume";
                    readonly type: "numeric(12,2)";
                    readonly nullable: true;
                    readonly default: 0;
                    readonly description: "Volume total de ajustes no evento.";
                }, {
                    readonly name: "inventory_stock_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao estoque associado ao evento.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada ao ajuste, quando aplicável.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou a movimentação.";
                }, {
                    readonly name: "actor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Usuário que executou a movimentação, quando disponível.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "partId";
                    readonly column: "part_id";
                    readonly type: "uuid";
                    readonly description: "Peça relacionada";
                }, {
                    readonly dimensionId: "commandType";
                    readonly column: "command_type";
                    readonly type: "text";
                    readonly description: "Tipo de movimentação";
                }, {
                    readonly dimensionId: "isLowStock";
                    readonly column: "is_low_stock";
                    readonly type: "boolean";
                    readonly description: "Indicador de estoque abaixo do mínimo";
                }];
                readonly measures: readonly [{
                    readonly measureId: "stockLevel";
                    readonly column: "stock_level";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Nível atual de estoque";
                }, {
                    readonly measureId: "lowStockCount";
                    readonly column: "low_stock_count";
                    readonly aggregation: "sum";
                    readonly description: "Contagem de itens com estoque baixo";
                }, {
                    readonly measureId: "adjustmentVolume";
                    readonly column: "adjustment_volume";
                    readonly aggregation: "sum";
                    readonly unit: "units";
                    readonly description: "Volume total de ajustes";
                }];
                readonly sourceWriteEvents: readonly ["adjustInventory", "addPartToServiceOrder"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_inventory_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Acelerar consultas por período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_part_time";
                        readonly columns: readonly ["part_id", "event_at"];
                        readonly purpose: "Filtrar métricas por peça e período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_command_time";
                        readonly columns: readonly ["command_type", "event_at"];
                        readonly purpose: "Filtrar métricas por tipo de movimentação e período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_low_stock_time";
                        readonly columns: readonly ["is_low_stock", "event_at"];
                        readonly purpose: "Monitorar eventos de estoque baixo por período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["inventoryAdjustUsecaseEntities", "serviceOrderUsecaseEntities"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInventoryLowStock"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryMetrics.defs.ts";
                readonly exportName: "inventoryMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/invoiceMetrics.defs" {
    export const invoiceMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "invoiceMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "invoiceMetrics";
                readonly tableName: "invoice_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Faturamento";
                readonly purpose: "Consolidar receita e status de faturamento ao longo do tempo.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de faturamento agregado.";
                }, {
                    readonly name: "invoice_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da fatura.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "OS vinculada.";
                }, {
                    readonly name: "invoice_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de faturas no intervalo.";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total faturada no intervalo (BRL).";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "invoiceStatus";
                    readonly column: "invoice_status";
                    readonly type: "text";
                    readonly description: "Status da fatura";
                }, {
                    readonly dimensionId: "serviceOrderId";
                    readonly column: "service_order_id";
                    readonly type: "uuid";
                    readonly description: "OS vinculada";
                }];
                readonly measures: readonly [{
                    readonly measureId: "invoiceCount";
                    readonly column: "invoice_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de faturas";
                }, {
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total faturada";
                }];
                readonly sourceWriteEvents: readonly ["generateInvoice", "updateInvoiceStatus"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 anos";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_invoice_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Ordenação e consultas por tempo.";
                    }, {
                        readonly indexName: "idx_invoice_metrics_status_time";
                        readonly columns: readonly ["invoice_status", "event_at"];
                        readonly purpose: "Filtros por status e período.";
                    }, {
                        readonly indexName: "idx_invoice_metrics_service_order_time";
                        readonly columns: readonly ["service_order_id", "event_at"];
                        readonly purpose: "Filtros por OS e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["generateInvoice", "updateInvoiceStatus"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/invoiceMetrics.defs.ts";
                readonly exportName: "invoiceMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default invoiceMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/laborItem.defs" {
    export const laborItemTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "laborItem";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "laborItem";
                readonly tableName: "labor_item";
                readonly moduleId: "repairBay";
                readonly title: "Itens de Mão de Obra";
                readonly purpose: "Registrar serviços executados na OS com tempo e custo para cálculo do total e histórico.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LaborItem";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "labor_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do item de mão de obra.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à OS vinculada.";
                }, {
                    readonly name: "description";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Descrição do serviço executado.";
                }, {
                    readonly name: "labor_code";
                    readonly type: "varchar(50)";
                    readonly nullable: true;
                    readonly description: "Código interno do serviço, quando aplicável.";
                }, {
                    readonly name: "hours_worked";
                    readonly type: "numeric(10,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Horas trabalhadas no serviço.";
                }, {
                    readonly name: "hourly_rate";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor por hora aplicado ao serviço.";
                }, {
                    readonly name: "labor_total";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total calculado do item de mão de obra.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly default: "pending";
                    readonly description: "Status do item de mão de obra.";
                }, {
                    readonly name: "performed_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de execução do serviço.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora da última atualização.";
                }];
                readonly primaryKey: readonly ["labor_item_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular itens de mão de obra à OS para cálculo de total e histórico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_labor_item_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly reason: "Consulta de itens por OS nas telas de detalhe.";
                }, {
                    readonly indexName: "idx_labor_item_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtrar itens por status no fluxo da OS.";
                }, {
                    readonly indexName: "idx_labor_item_performed_at";
                    readonly columns: readonly ["performed_at"];
                    readonly reason: "Ordenação e filtros por data de execução no histórico do veículo.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/laborItem.defs.ts";
                readonly exportName: "laborItemTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default laborItemTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecast.defs" {
    export const maintenanceForecastTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "maintenanceForecast";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "maintenanceForecast";
                readonly tableName: "maintenance_forecast";
                readonly moduleId: "repairBay";
                readonly title: "Manutenções Previstas";
                readonly purpose: "Armazenar previsões de manutenção por veículo para consulta e métricas operacionais.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MaintenanceForecast";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "maintenance_forecast_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador da manutenção prevista.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao veículo MDM.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada que originou a previsão.";
                }, {
                    readonly name: "forecast_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data prevista para a manutenção.";
                }, {
                    readonly name: "forecast_mileage_km";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Quilometragem prevista para a manutenção.";
                }, {
                    readonly name: "forecast_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo de manutenção prevista (ex.: troca de óleo).";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status da previsão (active, completed, cancelled).";
                }, {
                    readonly name: "confidence_score";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Nível de confiança da previsão.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Última atualização do registro.";
                }];
                readonly primaryKey: readonly ["maintenance_forecast_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "vehicle_id";
                    readonly targetEntity: "Vehicle";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular previsão ao veículo do cliente.";
                }, {
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Relacionar previsão ao histórico de OS quando aplicável.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "ix_maintenance_forecast_vehicle";
                    readonly columns: readonly ["vehicle_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por veículo no histórico e dashboard.";
                }, {
                    readonly indexName: "ix_maintenance_forecast_status_date";
                    readonly columns: readonly ["status", "forecast_date"];
                    readonly unique: false;
                    readonly reason: "Filtrar previsões ativas por data para dashboard.";
                }, {
                    readonly indexName: "ix_maintenance_forecast_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Localizar previsão associada à OS.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["upcomingMaintenanceMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecast.defs.ts";
                readonly exportName: "maintenanceForecastTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecastCommandLog.defs" {
    export const maintenanceForecastCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "maintenanceForecastCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "maintenanceForecastCommandLog";
                readonly tableName: "maintenance_forecast_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Comandos de Manutenção Prevista";
                readonly purpose: "Registrar comandos de geração/atualização de previsões.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MaintenanceForecastCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "maintenance_forecast_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de comando.";
                }, {
                    readonly name: "maintenance_forecast_command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Comando de manutenção prevista relacionado.";
                }, {
                    readonly name: "maintenance_forecast_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Previsão de manutenção afetada.";
                }, {
                    readonly name: "command_type";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Tipo do comando (ex.: gerar, atualizar, recalcular).";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Status do comando no momento do log.";
                }, {
                    readonly name: "requested_by_role";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Perfil que solicitou a ação.";
                }, {
                    readonly name: "requested_by_user_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Usuário solicitante (quando disponível).";
                }, {
                    readonly name: "correlation_id";
                    readonly type: "varchar(80)";
                    readonly nullable: true;
                    readonly description: "Identificador de correlação do workflow.";
                }, {
                    readonly name: "attempt_number";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Número da tentativa de execução.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do log.";
                }];
                readonly primaryKey: readonly ["maintenance_forecast_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "maintenance_forecast_command_id";
                    readonly targetEntity: "MaintenanceForecastCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vínculo ao comando executado.";
                }, {
                    readonly fieldName: "maintenance_forecast_id";
                    readonly targetEntity: "MaintenanceForecast";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Rastrear a previsão gerada/atualizada.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_mf_cmd_log_command_id";
                    readonly columns: readonly ["maintenance_forecast_command_id"];
                    readonly reason: "Busca de logs por comando.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_forecast_id";
                    readonly columns: readonly ["maintenance_forecast_id"];
                    readonly reason: "Consulta por previsão afetada.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_status_time";
                    readonly columns: readonly ["status", "occurred_at"];
                    readonly reason: "Filtrar eventos por status e período.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_correlation";
                    readonly columns: readonly ["correlation_id"];
                    readonly reason: "Rastreio por correlação de workflow.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payload do comando e diagnósticos não filtrados com frequência.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecastCommandLog.defs.ts";
                readonly exportName: "maintenanceForecastCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecastMetrics.defs" {
    export const maintenanceForecastMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "maintenanceForecastMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "maintenanceForecastMetrics";
                readonly tableName: "maintenance_forecast_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Manutenção Prevista";
                readonly purpose: "Rastrear previsões de manutenção e veículos com serviços pendentes futuros.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de métrica.";
                }, {
                    readonly name: "forecast_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da previsão.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo da previsão.";
                }, {
                    readonly name: "forecast_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo de manutenção prevista.";
                }, {
                    readonly name: "forecast_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de previsões ativas.";
                }, {
                    readonly name: "upcoming_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de manutenções previstas para o período.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "forecastStatus";
                    readonly column: "forecast_status";
                    readonly type: "text";
                    readonly description: "Status da previsão";
                }, {
                    readonly dimensionId: "vehicleId";
                    readonly column: "vehicle_id";
                    readonly type: "uuid";
                    readonly description: "Veículo da previsão";
                }, {
                    readonly dimensionId: "forecastType";
                    readonly column: "forecast_type";
                    readonly type: "text";
                    readonly description: "Tipo de manutenção prevista";
                }];
                readonly measures: readonly [{
                    readonly measureId: "forecastCount";
                    readonly column: "forecast_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de previsões ativas";
                }, {
                    readonly measureId: "upcomingCount";
                    readonly column: "upcoming_count";
                    readonly aggregation: "sum";
                    readonly description: "Contagem de manutenções previstas para o período";
                }];
                readonly sourceWriteEvents: readonly ["maintenanceForecastCommand"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_maintenance_forecast_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Ordenação e consultas por tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_status_time";
                        readonly columns: readonly ["forecast_status", "event_at"];
                        readonly purpose: "Filtros por status e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_vehicle_time";
                        readonly columns: readonly ["vehicle_id", "event_at"];
                        readonly purpose: "Filtros por veículo e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_type_time";
                        readonly columns: readonly ["forecast_type", "event_at"];
                        readonly purpose: "Filtros por tipo e período.";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["maintenanceForecastWorkflow", "maintenanceForecastUsecaseEntities"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecastMetrics.defs.ts";
                readonly exportName: "maintenanceForecastMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/repairSuggestion.defs" {
    export const repairSuggestionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "repairSuggestion";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "repairSuggestion";
                readonly tableName: "repair_suggestion";
                readonly moduleId: "repairBay";
                readonly title: "Sugestões de Reparo";
                readonly purpose: "Guardar respostas da IA para reparos comuns e estimativas por veículo/OS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "RepairSuggestion";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "repairSuggestionId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da sugestão de reparo.";
                }, {
                    readonly name: "serviceOrderId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "OS relacionada à sugestão.";
                }, {
                    readonly name: "vehicleId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo relacionado à sugestão.";
                }, {
                    readonly name: "suggestionStatus";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status da sugestão (active, superseded, discarded).";
                }, {
                    readonly name: "suggestionDate";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data de referência usada na sugestão (ex.: data da OS).";
                }, {
                    readonly name: "createdAt";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora de criação.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora da última atualização.";
                }];
                readonly primaryKey: readonly ["repairSuggestionId"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "serviceOrderId";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular a sugestão à OS.";
                }, {
                    readonly fieldName: "vehicleId";
                    readonly targetEntity: "Vehicle";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular a sugestão ao veículo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_repair_suggestion_service_order";
                    readonly columns: readonly ["serviceOrderId", "suggestionStatus"];
                    readonly unique: false;
                    readonly reason: "Busca por sugestão ativa da OS.";
                }, {
                    readonly indexName: "idx_repair_suggestion_vehicle";
                    readonly columns: readonly ["vehicleId", "suggestionDate"];
                    readonly unique: false;
                    readonly reason: "Consulta por histórico de sugestões do veículo.";
                }, {
                    readonly indexName: "idx_repair_suggestion_created_at";
                    readonly columns: readonly ["createdAt"];
                    readonly unique: false;
                    readonly reason: "Ordenação por data para listagens recentes.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "RepairSuggestionDetails";
                    readonly reason: "Armazena conteúdo completo da resposta da IA e estimativas detalhadas.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/repairSuggestion.defs.ts";
                readonly exportName: "repairSuggestionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default repairSuggestionTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/serviceOrderCommandLog.defs" {
    export const serviceOrderCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceOrderCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 44;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceOrderCommandLog";
                readonly tableName: "service_order_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Comandos de OS";
                readonly purpose: "Auditar comandos de criação/atualização de OS para rastreabilidade.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceOrderCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_order_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de comando de OS.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência à OS afetada.";
                }, {
                    readonly name: "service_order_command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao comando de OS executado.";
                }, {
                    readonly name: "command_type";
                    readonly type: "varchar(60)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo do comando executado (criação, atualização, fechamento).";
                }, {
                    readonly name: "previous_status";
                    readonly type: "varchar(40)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Status anterior da OS, quando aplicável.";
                }, {
                    readonly name: "new_status";
                    readonly type: "varchar(40)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Novo status da OS, quando aplicável.";
                }, {
                    readonly name: "service_order_total";
                    readonly type: "decimal(12,2)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Total da OS após o comando.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "varchar(40)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Perfil do usuário que executou o comando.";
                }, {
                    readonly name: "actor_user_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Identificador do usuário executor, quando disponível.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do comando para auditoria e filtros.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Estado do registro de log (ativo, retido, arquivado).";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora de persistência do log.";
                }];
                readonly primaryKey: readonly ["service_order_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "OS impactada pelo comando.";
                }, {
                    readonly fieldName: "service_order_command_id";
                    readonly targetEntity: "ServiceOrderCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Comando registrado para auditoria.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_soclog_service_order_id";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de logs por OS.";
                }, {
                    readonly indexName: "idx_soclog_command_id";
                    readonly columns: readonly ["service_order_command_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear execuções de um comando específico.";
                }, {
                    readonly indexName: "idx_soclog_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período para auditoria.";
                }, {
                    readonly indexName: "idx_soclog_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Gestão de retenção e arquivamento.";
                }, {
                    readonly indexName: "idx_soclog_new_status";
                    readonly columns: readonly ["new_status"];
                    readonly unique: false;
                    readonly reason: "Auditoria de transições de status.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payloads e diffs do comando sem impactar consultas principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceOrderCommandLog.defs.ts";
                readonly exportName: "serviceOrderCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceOrderCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/serviceOrderMetrics.defs" {
    export const serviceOrderMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "serviceOrderMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "serviceOrderMetrics";
                readonly tableName: "service_order_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Ordens de Serviço";
                readonly purpose: "Acompanhar volume, status e valores das ordens de serviço ao longo do tempo.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de métrica.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da OS relacionada ao evento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da OS no momento do evento.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou a ação.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo vinculado à OS.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de ordens de serviço.";
                }, {
                    readonly name: "total_value";
                    readonly type: "numeric(14,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total acumulado das OS.";
                }, {
                    readonly name: "labor_total";
                    readonly type: "numeric(14,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total de mão de obra.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "text";
                    readonly description: "Status da OS no momento do evento.";
                }, {
                    readonly dimensionId: "actorRole";
                    readonly column: "actor_role";
                    readonly type: "text";
                    readonly description: "Perfil do usuário que executou a ação.";
                }, {
                    readonly dimensionId: "vehicleId";
                    readonly column: "vehicle_id";
                    readonly type: "uuid";
                    readonly description: "Veículo vinculado à OS.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de ordens de serviço.";
                }, {
                    readonly measureId: "totalValue";
                    readonly column: "total_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total acumulado das OS.";
                }, {
                    readonly measureId: "laborTotal";
                    readonly column: "labor_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total de mão de obra.";
                }];
                readonly sourceWriteEvents: readonly ["createServiceOrder", "updateServiceOrderStatus", "closeServiceOrder", "addLaborItem"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_service_order_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Acelerar consultas por período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_status_time";
                        readonly columns: readonly ["status", "event_at"];
                        readonly purpose: "Filtrar métricas por status e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_actor_role_time";
                        readonly columns: readonly ["actor_role", "event_at"];
                        readonly purpose: "Filtrar métricas por perfil e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_vehicle_time";
                        readonly columns: readonly ["vehicle_id", "event_at"];
                        readonly purpose: "Filtrar métricas por veículo e período.";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceOrderMetrics.defs.ts";
                readonly exportName: "serviceOrderMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceOrderMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/addLaborItem.defs" {
    export const useCase: {
        readonly usecaseId: "addLaborItem";
        readonly title: "Adicionar mão de obra";
        readonly purpose: "Registrar item de mão de obra e recalcular total da OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["laborItemUsecaseEntity", "serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["laborItemUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "addLaborItem";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "hoursWorked";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "hourlyRate";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "laborItemId";
                readonly type: "string";
            }, {
                readonly name: "serviceOrderTotal";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/addPartToServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "addPartToServiceOrder";
        readonly title: "Adicionar peça à OS";
        readonly purpose: "Registrar peça utilizada, baixar estoque e recalcular total da OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity", "serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Part";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_adjustment_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "addPartToServiceOrder";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "partId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "unitPrice";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderTotal";
                readonly type: "number";
            }, {
                readonly name: "newStockLevel";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleInventoryLowStock", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/adjustInventory.defs" {
    export const useCase: {
        readonly usecaseId: "adjustInventory";
        readonly title: "Ajustar estoque";
        readonly purpose: "Aplicar ajustes manuais de estoque e registrar o comando.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly outputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Part";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_adjustment_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "adjustInventory";
            readonly input: readonly [{
                readonly name: "inventoryStockId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "partId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantityDelta";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "reasonCode";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "newQuantity";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/closeServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "closeServiceOrder";
        readonly title: "Fechar OS";
        readonly purpose: "Fechar a OS confirmando total e registrando o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "closeServiceOrder";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/createServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "createServiceOrder";
        readonly title: "Criar OS";
        readonly purpose: "Criar uma nova ordem de serviço e registrar o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Customer";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "createServiceOrder";
            readonly input: readonly [{
                readonly name: "customerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderStatus", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/generateInvoice.defs" {
    export const useCase: {
        readonly usecaseId: "generateInvoice";
        readonly title: "Gerar fatura";
        readonly purpose: "Criar fatura a partir da OS concluída.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "generateInvoice";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/generateMaintenanceForecast.defs" {
    export const useCase: {
        readonly usecaseId: "generateMaintenanceForecast";
        readonly title: "Gerar manutenção prevista";
        readonly purpose: "Gerar ou atualizar previsões de manutenção com base no histórico.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["maintenanceForecastUsecaseEntity", "maintenanceForecastCommandUsecaseEntity"];
        readonly outputEntities: readonly ["maintenanceForecastUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "maintenance_forecast";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "generateMaintenanceForecast";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "forecastDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "forecastMileageKm";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "forecastType";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "maintenanceForecastId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/requestRepairSuggestion.defs" {
    export const useCase: {
        readonly usecaseId: "requestRepairSuggestion";
        readonly title: "Solicitar sugestão de reparo";
        readonly purpose: "Gerar e armazenar sugestão de reparo via IA para a OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["repairSuggestionUsecaseEntity"];
        readonly outputEntities: readonly ["repairSuggestionUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "repair_suggestion";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "requestRepairSuggestion";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "issueDescription";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "repairSuggestionId";
                readonly type: "string";
            }, {
                readonly name: "suggestionStatus";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/updateInvoiceStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateInvoiceStatus";
        readonly title: "Atualizar status da fatura";
        readonly purpose: "Atualizar status de faturamento interno.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateInvoiceStatus";
            readonly input: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/updateServiceOrderStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateServiceOrderStatus";
        readonly title: "Atualizar status da OS";
        readonly purpose: "Atualizar o status da OS seguindo o ciclo de vida e registrar o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateServiceOrderStatus";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStatus";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/viewDashboardMetrics.defs" {
    export const useCase: {
        readonly usecaseId: "viewDashboardMetrics";
        readonly title: "Visualizar dashboard operacional";
        readonly purpose: "Consultar métricas operacionais consolidadas para o painel.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "viewDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "openServiceOrders";
                readonly type: "number";
            }, {
                readonly name: "monthlyRevenue";
                readonly type: "number";
            }, {
                readonly name: "upcomingMaintenance";
                readonly type: "number";
            }, {
                readonly name: "lowStockCount";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/viewVehicleHistory.defs" {
    export const useCase: {
        readonly usecaseId: "viewVehicleHistory";
        readonly title: "Consultar histórico do veículo";
        readonly purpose: "Consultar histórico completo de serviços, peças e custos por veículo/cliente.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "Customer";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "viewVehicleHistory";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "customerId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrdersCount";
                readonly type: "number";
            }, {
                readonly name: "totalSpent";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102044_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102044_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102044_/l2/repairBay/customerDetail.defs" {
    export const customerDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerDetail";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerDetail";
                readonly pageName: "Criar ordem de serviço";
                readonly actor: "attendant";
                readonly purpose: "Registrar nova OS com cliente, veículo e itens iniciais.";
                readonly capabilities: readonly ["serviceOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly ["serviceOrderWorkflow"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["serviceOrder", "customer", "vehicle", "partInventory"];
                readonly pageInputs: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do cliente selecionado para a OS.";
                    readonly entityRef: "Customer";
                    readonly fieldRef: "customerId";
                }, {
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do veículo selecionado para a OS.";
                    readonly entityRef: "Vehicle";
                    readonly fieldRef: "vehicleId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "serviceOrderList";
                    readonly trigger: "Ação criar OS";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "serviceOrderDetail";
                    readonly trigger: "OS criada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do cliente e veículo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "customerVehicleSummary";
                        readonly purpose: "Exibir cliente e veículo selecionados antes da criação da OS.";
                        readonly userActions: readonly ["confirmarSelecao"];
                        readonly requiredEntities: readonly ["Customer", "Vehicle"];
                        readonly readsFields: readonly ["Customer.customerId", "Customer.name", "Customer.phone", "Vehicle.vehicleId", "Vehicle.plate", "Vehicle.model", "Vehicle.year"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Dados iniciais da OS";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderNotesForm";
                        readonly purpose: "Registrar observações iniciais da OS.";
                        readonly userActions: readonly ["preencherObservacoes"];
                        readonly requiredEntities: readonly ["ServiceOrder"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["ServiceOrder.notes"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de criação";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderCreateAction";
                        readonly purpose: "Confirmar criação da OS com cliente e veículo selecionados.";
                        readonly userActions: readonly ["criarOS"];
                        readonly requiredEntities: readonly ["ServiceOrder", "ServiceOrderCommand", "Customer", "Vehicle"];
                        readonly readsFields: readonly ["Customer.customerId", "Vehicle.vehicleId", "ServiceOrder.notes"];
                        readonly writesFields: readonly ["ServiceOrder.serviceOrderId", "ServiceOrder.status", "ServiceOrder.total", "ServiceOrderCommand.serviceOrderCommandId"];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderTotal", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "initServiceOrder";
                readonly purpose: "Criar OS e retornar identificador e status inicial.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Customer", "Vehicle"];
                readonly writesEntities: readonly ["ServiceOrder", "ServiceOrderCommand"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["service_order_command_log", "service_order_metrics"];
                readonly usecaseRefs: readonly ["createServiceOrder"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderTotal", "ruleRoleAccess"];
            }];
        };
    };
    export default customerDetailPagePlan;
}
declare module "_102044_/l2/repairBay/customerList.defs" {
    export const customerListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerList";
                readonly pageName: "Dashboard de métricas";
                readonly actor: "shopOwner";
                readonly purpose: "Acompanhar métricas consolidadas do negócio.";
                readonly capabilities: readonly ["dashboardInsights"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "cardsResumoMetricas";
                        readonly purpose: "Exibir indicadores consolidados do negócio.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Detalhamento de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "tabelaMetricasConsolidadas";
                        readonly purpose: "Apresentar tabelas consolidadas de métricas operacionais.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getMetricDashboard";
                readonly purpose: "Carregar tabelas de métricas";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "openServiceOrders";
                    readonly type: "number";
                }, {
                    readonly name: "monthlyRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "upcomingMaintenance";
                    readonly type: "number";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["service_order_metrics", "inventory_metrics", "invoice_metrics", "maintenance_forecast_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }];
        };
    };
    export default customerListPagePlan;
}
declare module "_102044_/l2/repairBay/serviceOrderList.defs" {
    export const serviceOrderListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "serviceOrderList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "serviceOrderList";
                readonly pageName: "Gerar fatura";
                readonly actor: "shopOwner";
                readonly purpose: "Selecionar OS e confirmar geração de fatura.";
                readonly capabilities: readonly ["billingManagement"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["billingWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["invoice", "serviceOrder"];
                readonly pageInputs: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador da OS selecionada para gerar a fatura.";
                    readonly entityRef: "ServiceOrder";
                    readonly fieldRef: "serviceOrderId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "invoiceList";
                    readonly trigger: "Ação gerar fatura";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "invoiceDetail";
                    readonly trigger: "Fatura gerada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo da OS";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderSummary";
                        readonly purpose: "Exibir dados essenciais da OS para validação antes da emissão da fatura.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["ServiceOrder"];
                        readonly readsFields: readonly ["serviceOrderId", "status", "total", "customerName", "vehiclePlate", "closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Condições de pagamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "paymentTermsForm";
                        readonly purpose: "Informar condições de pagamento para a fatura.";
                        readonly userActions: readonly ["informPaymentTerms"];
                        readonly requiredEntities: readonly ["Invoice"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["paymentTerms", "dueDate", "paymentMethod"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de emissão";
                    readonly mode: "commit";
                    readonly organisms: readonly [{
                        readonly organismName: "generateInvoiceAction";
                        readonly purpose: "Confirmar geração da fatura vinculada à OS.";
                        readonly userActions: readonly ["generateInvoice"];
                        readonly requiredEntities: readonly ["Invoice", "ServiceOrder", "InvoiceCommand"];
                        readonly readsFields: readonly ["serviceOrderId", "total", "paymentTerms", "dueDate", "paymentMethod"];
                        readonly writesFields: readonly ["invoiceId", "status", "serviceOrderId", "total"];
                        readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getServiceOrderSummaryForInvoice";
                readonly purpose: "Consultar dados resumidos da OS para confirmação de faturamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "vehiclePlate";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["ServiceOrder"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
            }, {
                readonly commandName: "createInvoiceFromServiceOrder";
                readonly purpose: "Gerar fatura a partir da OS com condições de pagamento.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "paymentTerms";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dueDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "paymentMethod";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["ServiceOrder"];
                readonly writesEntities: readonly ["Invoice", "InvoiceCommand"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["invoice_metrics"];
                readonly usecaseRefs: readonly ["generateInvoice"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
            }];
        };
    };
    export default serviceOrderListPagePlan;
}
declare module "_102044_/l2/repairBay/vehicleDetail.defs" {
    export const vehicleDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "vehicleDetail";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "vehicleDetail";
                readonly pageName: "Detalhe do veículo";
                readonly actor: "attendant";
                readonly purpose: "Cadastrar ou atualizar informações do veículo e vínculo com cliente.";
                readonly capabilities: readonly ["manageVehicles"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["vehicle", "customer"];
                readonly pageInputs: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do veículo para edição.";
                    readonly entityRef: "Vehicle";
                    readonly fieldRef: "Vehicle.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "vehicleList";
                    readonly trigger: "Abrir veículo ou criar novo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "vehicleList";
                    readonly trigger: "Salvar veículo";
                    readonly description: "Retorno após criação/atualização do veículo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados do veículo";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VehicleForm";
                        readonly purpose: "Cadastrar ou editar dados do veículo.";
                        readonly userActions: readonly ["preencherDadosVeiculo", "salvarVeiculo"];
                        readonly requiredEntities: readonly ["Vehicle"];
                        readonly readsFields: readonly ["Vehicle.id", "Vehicle.make", "Vehicle.model", "Vehicle.year", "Vehicle.plate", "Vehicle.vin"];
                        readonly writesFields: readonly ["Vehicle.make", "Vehicle.model", "Vehicle.year", "Vehicle.plate", "Vehicle.vin"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Vínculo com cliente";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "CustomerSelector";
                        readonly purpose: "Selecionar cliente ativo para vínculo do veículo.";
                        readonly userActions: readonly ["buscarCliente", "selecionarCliente"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly ["Customer.id", "Customer.name", "Customer.status"];
                        readonly writesFields: readonly ["Vehicle.customerId"];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getVehicle";
                readonly purpose: "Carregar dados do veículo para edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "vehicleRef";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                }, {
                    readonly name: "make";
                    readonly type: "string";
                }, {
                    readonly name: "model";
                    readonly type: "string";
                }, {
                    readonly name: "year";
                    readonly type: "number";
                }, {
                    readonly name: "plate";
                    readonly type: "string";
                }, {
                    readonly name: "vin";
                    readonly type: "string";
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "customerStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Vehicle", "Customer"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly commandName: "searchCustomers";
                readonly purpose: "Buscar clientes para seleção de vínculo.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "customerStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly commandName: "saveVehicle";
                readonly purpose: "Criar ou atualizar veículo com vínculo ao cliente.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "vehicleRef";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "make";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "model";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "year";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "plate";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "vin";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly ["Vehicle"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
            }];
        };
    };
    export default vehicleDetailPagePlan;
}
declare module "_102044_/l2/repairBay/vehicleList.defs" {
    export const vehicleListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "vehicleList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "vehicleList";
                readonly pageName: "Dashboard operacional";
                readonly actor: "shopOwner";
                readonly purpose: "Visualizar indicadores operacionais do dia a dia.";
                readonly capabilities: readonly ["dashboardInsights"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["maintenanceForecastWorkflow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "cardsResumoOperacional";
                        readonly purpose: "Exibir indicadores operacionais consolidados.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOperationalSummary";
                readonly purpose: "Carregar indicadores operacionais";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "openServiceOrders";
                    readonly type: "number";
                }, {
                    readonly name: "monthlyRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "upcomingMaintenance";
                    readonly type: "number";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["service_order_metrics", "inventory_metrics", "invoice_metrics", "maintenance_forecast_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }];
        };
    };
    export default vehicleListPagePlan;
}
declare module "_102044_/l4/workflows/billingWorkflow.defs" {
    export const billingWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "billingWorkflow";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "billingWorkflow";
                readonly title: "Fluxo de Faturamento";
                readonly purpose: "Controlar a geração de faturas a partir de ordens de serviço concluídas e acompanhar seus status até a quitação.";
                readonly executionMode: "entityLifecycle";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["shopOwner"];
                readonly states: readonly [{
                    readonly stateId: "draft";
                    readonly description: "Fatura preparada para emissão a partir de uma OS concluída.";
                }, {
                    readonly stateId: "issued";
                    readonly description: "Fatura emitida e aguardando pagamento.";
                }, {
                    readonly stateId: "paid";
                    readonly description: "Fatura quitada.";
                }, {
                    readonly stateId: "canceled";
                    readonly description: "Fatura cancelada.";
                }];
                readonly transitions: readonly [{
                    readonly from: "draft";
                    readonly to: "issued";
                    readonly trigger: "generateInvoice";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                }, {
                    readonly from: "issued";
                    readonly to: "paid";
                    readonly trigger: "markInvoicePaid";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleRoleAccess"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly from: "draft";
                    readonly to: "canceled";
                    readonly trigger: "cancelInvoice";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleRoleAccess"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly from: "issued";
                    readonly to: "canceled";
                    readonly trigger: "cancelInvoice";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleRoleAccess"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }];
                readonly requiredEntities: readonly ["Invoice", "ServiceOrder", "InvoiceCommand"];
                readonly persistenceRefs: readonly [];
                readonly usecaseRefs: readonly ["invoiceUsecaseEntities"];
                readonly metricRefs: readonly ["invoiceMetrics"];
                readonly userActions: readonly ["generateInvoice", "markInvoicePaid", "cancelInvoice"];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "invoiceFromClosedSO";
                    readonly title: "Permitir fatura apenas de OS concluída";
                    readonly priority: "soon";
                    readonly description: "Validar no caso de uso que a OS esteja concluída antes de emitir a fatura, garantindo o vínculo obrigatório.";
                    readonly tradeoff: "Pode impedir emissão rápida em exceções operacionais.";
                }, {
                    readonly suggestionId: "linkInvoiceToSO";
                    readonly title: "Vincular fatura à OS no workflow";
                    readonly priority: "soon";
                    readonly description: "Persistir o vínculo entre fatura e OS para rastreabilidade e consultas futuras.";
                    readonly tradeoff: "Requer ajustes de persistência e validação no caso de uso.";
                }, {
                    readonly suggestionId: "noManualTask";
                    readonly title: "Não gerar tarefas manuais no faturamento";
                    readonly priority: "later";
                    readonly description: "Manter o fluxo como ciclo de vida da entidade, sem tarefas, pois a emissão e quitação podem ser feitas diretamente pelo dono da oficina.";
                    readonly tradeoff: "Sem tarefas, não há fila de trabalho dedicada para cobrança ativa.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["repairBay"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "repairBay";
                    readonly entity: "Invoice";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "ServiceOrder";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "InvoiceCommand";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "repairBay";
                    readonly artifactType: "workflow";
                    readonly artifactId: "billingWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/billingWorkflow.defs.ts";
                readonly exportName: "billingWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default billingWorkflowDef;
}
declare module "_102044_/l4/workflows/inventoryAlertWorkflow.defs" {
    export const inventoryAlertWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "inventoryAlertWorkflow";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "inventoryAlertWorkflow";
                readonly title: "Alerta de Estoque";
                readonly purpose: "Monitorar níveis de peças e disparar alertas operacionais quando o estoque estiver abaixo do mínimo configurado, gerando ações para reposição.";
                readonly executionMode: "automation";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "Revisar estoque baixo: {{partName}}";
                    readonly assigneeRules: readonly ["assignToRole:shopOwner"];
                    readonly slaRules: readonly ["dueIn:24h"];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["shopOwner"];
                readonly states: readonly [{
                    readonly stateId: "monitoring";
                    readonly description: "Estoque monitorado aguardando verificações periódicas ou ajustes registrados.";
                }, {
                    readonly stateId: "lowStockDetected";
                    readonly description: "Estoque abaixo do mínimo configurado identificado para uma ou mais peças.";
                }, {
                    readonly stateId: "taskCreated";
                    readonly description: "Tarefa de reposição criada e aguardando ação do dono da oficina.";
                }, {
                    readonly stateId: "resolved";
                    readonly description: "Ação de reposição confirmada ou estoque normalizado.";
                }];
                readonly transitions: readonly [{
                    readonly from: "monitoring";
                    readonly to: "lowStockDetected";
                    readonly trigger: "scheduledStockCheck";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleInventoryLowStock"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
                }, {
                    readonly from: "monitoring";
                    readonly to: "lowStockDetected";
                    readonly trigger: "inventoryAdjustmentLogged";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly ["ruleInventoryLowStock"];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
                }, {
                    readonly from: "lowStockDetected";
                    readonly to: "taskCreated";
                    readonly trigger: "createLowStockTask";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly from: "taskCreated";
                    readonly to: "resolved";
                    readonly trigger: "confirmReplenishment";
                    readonly actor: "shopOwner";
                    readonly conditions: readonly [];
                    readonly actions: readonly [];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }];
                readonly requiredEntities: readonly ["InventoryStock", "Part", "InventoryAdjustmentCommand"];
                readonly persistenceRefs: readonly ["inventoryAdjustmentCommandLog"];
                readonly usecaseRefs: readonly ["inventoryAdjustUsecaseEntities"];
                readonly metricRefs: readonly ["inventoryMetrics"];
                readonly userActions: readonly ["Executar verificação diária de estoque", "Revisar tarefa de reposição", "Confirmar reposição de peças"];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "autoTaskLowStock";
                    readonly title: "Gerar tarefa automática para estoque baixo";
                    readonly priority: "now";
                    readonly description: "Quando o estoque ficar abaixo do mínimo, criar tarefa para o dono da oficina revisar e reabastecer.";
                    readonly tradeoff: "Aumenta a carga de tarefas diárias, mas melhora a disciplina de reposição.";
                }, {
                    readonly suggestionId: "scheduledStockCheck";
                    readonly title: "Verificação agendada de estoque";
                    readonly priority: "now";
                    readonly description: "Executar rotina diária para avaliar níveis de estoque e disparar alertas de forma proativa.";
                    readonly tradeoff: "Processamento recorrente diário, porém reduz risco de ruptura de estoque.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["repairBay"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "repairBay";
                    readonly entity: "InventoryStock";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "Part";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "InventoryAdjustmentCommand";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "repairBay";
                    readonly artifactType: "workflow";
                    readonly artifactId: "inventoryAlertWorkflow";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "table";
                    readonly artifactId: "inventoryAdjustmentCommandLog";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "metricTable";
                    readonly artifactId: "inventoryMetrics";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "usecase";
                    readonly artifactId: "inventoryAdjustUsecaseEntities";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/inventoryAlertWorkflow.defs.ts";
                readonly exportName: "inventoryAlertWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryAlertWorkflowDef;
}
declare module "_102044_/l4/workflows/maintenanceForecastWorkflow.defs" {
    export const maintenanceForecastWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "maintenanceForecastWorkflow";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 55;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "maintenanceForecastWorkflow";
                readonly title: "Geração de Manutenção Prevista";
                readonly purpose: "Gerar e atualizar previsões de manutenção com base no histórico de serviços do veículo, alimentando alertas no dashboard operacional.";
                readonly executionMode: "automation";
                readonly createsTask: false;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "";
                    readonly assigneeRules: readonly [];
                    readonly slaRules: readonly [];
                    readonly taskRoomRequired: false;
                };
                readonly actors: readonly ["shopOwner"];
                readonly states: readonly [{
                    readonly stateId: "scheduled";
                    readonly description: "Recalculo agendado para executar geração de previsões.";
                }, {
                    readonly stateId: "processing";
                    readonly description: "Processando histórico de OS e recalculando previsões por veículo.";
                }, {
                    readonly stateId: "forecastUpdated";
                    readonly description: "Previsões geradas ou atualizadas com sucesso.";
                }, {
                    readonly stateId: "failed";
                    readonly description: "Falha ao executar o recalculo das previsões.";
                }];
                readonly transitions: readonly [{
                    readonly from: "scheduled";
                    readonly to: "processing";
                    readonly trigger: "runScheduledJob";
                    readonly actor: "system";
                    readonly conditions: readonly ["ruleRoleAccess"];
                    readonly actions: readonly ["maintenanceForecastCommand.commandType=generate", "maintenanceForecastCommand.status=processing", "maintenanceForecastCommand.requestedByRole=shopOwner"];
                    readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
                }, {
                    readonly from: "processing";
                    readonly to: "forecastUpdated";
                    readonly trigger: "applyForecastResults";
                    readonly actor: "system";
                    readonly conditions: readonly ["ruleMaintenanceForecast"];
                    readonly actions: readonly ["maintenanceForecast.status=active", "maintenanceForecast.updatedAt=now()", "maintenanceForecastCommand.status=completed"];
                    readonly rulesApplied: readonly ["ruleMaintenanceForecast"];
                }, {
                    readonly from: "processing";
                    readonly to: "failed";
                    readonly trigger: "failForecastJob";
                    readonly actor: "system";
                    readonly conditions: readonly [];
                    readonly actions: readonly ["maintenanceForecastCommand.status=failed"];
                    readonly rulesApplied: readonly ["ruleMaintenanceForecast"];
                }];
                readonly requiredEntities: readonly ["MaintenanceForecast", "MaintenanceForecastCommand", "Vehicle", "ServiceOrder"];
                readonly persistenceRefs: readonly ["maintenanceForecast", "maintenanceForecastCommandLog"];
                readonly usecaseRefs: readonly ["maintenanceForecastUsecaseEntities"];
                readonly metricRefs: readonly ["maintenanceForecastMetrics"];
                readonly userActions: readonly [];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "nightlyForecastRecalc";
                    readonly title: "Recalcular previsões diariamente";
                    readonly priority: "soon";
                    readonly description: "Agendar execução noturna do workflow para recalcular previsões com base em OS fechadas, usando o usecase maintenanceForecastUsecaseEntities.";
                    readonly tradeoff: "Mais consumo de recursos fora do horário comercial, mas mantém previsões sempre atuais.";
                }, {
                    readonly suggestionId: "dashboardAlertForecast";
                    readonly title: "Exibir alerta no dashboard para manutenções próximas";
                    readonly priority: "soon";
                    readonly description: "Consumir maintenanceForecastMetrics no dashboard operacional para destacar veículos com manutenção prevista.";
                    readonly tradeoff: "Requer ajustes no dashboard e consultas de métricas.";
                }, {
                    readonly suggestionId: "noTaskAutomation";
                    readonly title: "Manter automação sem criação de tarefas";
                    readonly priority: "now";
                    readonly description: "O fluxo é totalmente automatizado e não cria tarefas; ações manuais devem ocorrer no dashboard via alertas e filtros.";
                    readonly tradeoff: "Menos rastreabilidade de ações humanas, porém menor carga operacional.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["repairBay"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "repairBay";
                    readonly entity: "MaintenanceForecast";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "MaintenanceForecastCommand";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "Vehicle";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "ServiceOrder";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "repairBay";
                    readonly artifactType: "usecase";
                    readonly artifactId: "maintenanceForecastUsecaseEntities";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "table";
                    readonly artifactId: "maintenanceForecast";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "table";
                    readonly artifactId: "maintenanceForecastCommandLog";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "metricTable";
                    readonly artifactId: "maintenanceForecastMetrics";
                }, {
                    readonly moduleId: "repairBay";
                    readonly artifactType: "workflow";
                    readonly artifactId: "maintenanceForecastWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/maintenanceForecastWorkflow.defs.ts";
                readonly exportName: "maintenanceForecastWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastWorkflowDef;
}
declare module "_102044_/l4/workflows/serviceOrderWorkflow.defs" {
    export const serviceOrderWorkflowDef: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "workflow";
        readonly artifactId: "serviceOrderWorkflow";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanWorkflowDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly workflowDefinition: {
                readonly workflowId: "serviceOrderWorkflow";
                readonly title: "Fluxo da Ordem de Serviço";
                readonly purpose: "Gerenciar o ciclo de vida da OS desde a abertura até o fechamento, coordenando ações entre atendente e mecânico, registrando mão de obra, peças e transições de status.";
                readonly executionMode: "taskWorkflow";
                readonly createsTask: true;
                readonly taskConfig: {
                    readonly taskTitleTemplate: "OS {{serviceOrderId}} - {{status}}";
                    readonly assigneeRules: readonly ["attendantReceivesWhenStatusCompleted", "mechanicReceivesWhenStatusInExecution"];
                    readonly slaRules: readonly ["inExecutionSla24h", "completedSla8h"];
                    readonly taskRoomRequired: true;
                };
                readonly actors: readonly ["attendant", "mechanic"];
                readonly states: readonly [{
                    readonly stateId: "opened";
                    readonly description: "OS aberta aguardando início dos serviços.";
                }, {
                    readonly stateId: "inExecution";
                    readonly description: "OS em execução pelo mecânico.";
                }, {
                    readonly stateId: "waitingPart";
                    readonly description: "OS aguardando chegada de peça.";
                }, {
                    readonly stateId: "completed";
                    readonly description: "Serviços concluídos aguardando fechamento pelo atendente.";
                }, {
                    readonly stateId: "closed";
                    readonly description: "OS fechada e finalizada.";
                }, {
                    readonly stateId: "canceled";
                    readonly description: "OS cancelada.";
                }];
                readonly transitions: readonly [{
                    readonly from: "opened";
                    readonly to: "inExecution";
                    readonly trigger: "startService";
                    readonly actor: "mechanic";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=em_execucao", "ServiceOrderCommand.commandType=iniciar_execucao"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "inExecution";
                    readonly to: "waitingPart";
                    readonly trigger: "awaitPart";
                    readonly actor: "mechanic";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=aguardando_peca", "ServiceOrderCommand.commandType=aguardar_peca"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "waitingPart";
                    readonly to: "inExecution";
                    readonly trigger: "partArrived";
                    readonly actor: "mechanic";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=em_execucao", "ServiceOrderCommand.commandType=retomar_execucao"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "inExecution";
                    readonly to: "inExecution";
                    readonly trigger: "addLaborItem";
                    readonly actor: "mechanic";
                    readonly conditions: readonly ["ruleRoleAccess", "ruleServiceOrderTotal"];
                    readonly actions: readonly ["LaborItem.status=pending", "ServiceOrderCommand.commandType=registrar_mao_de_obra"];
                    readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
                }, {
                    readonly from: "inExecution";
                    readonly to: "completed";
                    readonly trigger: "completeService";
                    readonly actor: "mechanic";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=concluida", "ServiceOrderCommand.commandType=concluir_servico"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "completed";
                    readonly to: "closed";
                    readonly trigger: "closeServiceOrder";
                    readonly actor: "attendant";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=fechada", "ServiceOrderCommand.commandType=fechar_os"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "opened";
                    readonly to: "canceled";
                    readonly trigger: "cancelServiceOrder";
                    readonly actor: "attendant";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=cancelada", "ServiceOrderCommand.commandType=cancelar_os"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "inExecution";
                    readonly to: "canceled";
                    readonly trigger: "cancelInExecution";
                    readonly actor: "attendant";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=cancelada", "ServiceOrderCommand.commandType=cancelar_os"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly from: "waitingPart";
                    readonly to: "canceled";
                    readonly trigger: "cancelWaitingPart";
                    readonly actor: "attendant";
                    readonly conditions: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                    readonly actions: readonly ["ServiceOrder.status=cancelada", "ServiceOrderCommand.commandType=cancelar_os"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }];
                readonly requiredEntities: readonly ["ServiceOrder", "LaborItem", "Part", "ServiceOrderCommand"];
                readonly persistenceRefs: readonly ["serviceOrderCommandLog", "laborItem"];
                readonly usecaseRefs: readonly ["serviceOrderUsecaseEntities"];
                readonly metricRefs: readonly ["serviceOrderMetrics"];
                readonly userActions: readonly ["iniciarExecucao", "aguardarPeca", "retomarExecucao", "registrarMaoDeObra", "concluirServico", "fecharOS", "cancelarOS"];
                readonly relatedPages: readonly [];
                readonly relatedAgents: readonly [];
                readonly relatedPlugins: readonly [];
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
                readonly implementationSuggestions: readonly [{
                    readonly suggestionId: "taskOnStatusChange";
                    readonly title: "Criar tarefa ao mudar status da OS";
                    readonly priority: "now";
                    readonly description: "Gerar tarefas para o mecânico ao iniciar execução e para o atendente ao concluir, com título e SLA derivados do status da OS.";
                    readonly tradeoff: "Aumenta carga de notificações e exige configuração de filas/SLAs.";
                }, {
                    readonly suggestionId: "validateStatusTransition";
                    readonly title: "Validar transições de status no backend";
                    readonly priority: "now";
                    readonly description: "Centralizar a validação do ciclo de vida da OS em casos de uso para garantir consistência e auditoria.";
                    readonly tradeoff: "Exige mais lógica nos casos de uso e testes adicionais.";
                }];
                readonly workflowScope: "singleModule";
                readonly moduleRefs: readonly ["repairBay"];
                readonly pageRefsByModule: readonly [];
                readonly entityRefsByModule: readonly [{
                    readonly moduleId: "repairBay";
                    readonly entity: "ServiceOrder";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "LaborItem";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "Part";
                }, {
                    readonly moduleId: "repairBay";
                    readonly entity: "ServiceOrderCommand";
                }];
                readonly writesArtifacts: readonly [{
                    readonly moduleId: "repairBay";
                    readonly artifactType: "workflow";
                    readonly artifactId: "serviceOrderWorkflow";
                }];
            };
            readonly defsPlan: {
                readonly fileName: "workflows/serviceOrderWorkflow.defs.ts";
                readonly exportName: "serviceOrderWorkflowDef";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceOrderWorkflowDef;
}
declare module "_102044_/l5/customer/module.defs" {
    export const customerMdmModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmDomain";
        readonly artifactId: "customer";
        readonly moduleName: "customer";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdm";
            readonly moduleId: "customer";
            readonly domainId: "customer";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly domain: {
                readonly domainId: "customer";
                readonly title: "Cliente";
                readonly masterEntities: readonly ["Customer"];
                readonly sourceOfTruth: "customerMasterData";
                readonly consumers: readonly ["customerManagementPage", "vehicleManagementPage", "vehicleHistoryPage"];
                readonly governanceRules: readonly ["Dados de contato mínimos obrigatórios para cadastro.", "Cliente não pode ser excluído se possuir veículos ou OS vinculadas.", "Atualizações restritas ao perfil atendente e dono da oficina."];
            };
        };
    };
    export default customerMdmModulePlan;
}
declare module "_102044_/l5/finance/module.defs" {
    export const financeModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "horizontalModule";
        readonly artifactId: "finance";
        readonly moduleName: "finance";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanHorizontals";
            readonly stepId: 13;
            readonly planId: "plan-horizontals";
        };
        readonly data: {
            readonly kind: "horizontal";
            readonly moduleId: "finance";
            readonly horizontalModuleId: "finance";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly module: {
                readonly horizontalModuleId: "finance";
                readonly priority: "now";
                readonly reason: "Escopo inclui faturamento com faturas vinculadas à OS no MVP.";
                readonly reusedOntologyRefs: readonly ["Invoice"];
                readonly consumedByArtifacts: readonly ["billingWorkflow", "billingPage", "invoiceMasterData"];
            };
        };
    };
    export default financeModulePlan;
}
declare module "_102044_/l5/invoice/module.defs" {
    export const invoiceMdmModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmDomain";
        readonly artifactId: "invoice";
        readonly moduleName: "invoice";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdm";
            readonly moduleId: "invoice";
            readonly domainId: "invoice";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly domain: {
                readonly domainId: "invoice";
                readonly title: "Fatura";
                readonly masterEntities: readonly ["Invoice"];
                readonly sourceOfTruth: "invoiceMasterData";
                readonly consumers: readonly ["billingPage", "vehicleHistoryPage", "billingWorkflow", "invoiceUsecaseEntities", "metricTableOps"];
                readonly governanceRules: readonly ["Fatura gerada exclusivamente a partir de OS concluída.", "Total da fatura deve refletir o valor consolidado da OS.", "Status de faturamento atualizado pelo fluxo próprio de billingWorkflow."];
            };
        };
    };
    export default invoiceMdmModulePlan;
}
declare module "_102044_/l5/notifications/module.defs" {
    export const notificationsModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "horizontalModule";
        readonly artifactId: "notifications";
        readonly moduleName: "notifications";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanHorizontals";
            readonly stepId: 13;
            readonly planId: "plan-horizontals";
        };
        readonly data: {
            readonly kind: "horizontal";
            readonly moduleId: "notifications";
            readonly horizontalModuleId: "notifications";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly module: {
                readonly horizontalModuleId: "notifications";
                readonly priority: "soon";
                readonly reason: "Alertas de estoque baixo exigem comunicação operacional dedicada.";
                readonly reusedOntologyRefs: readonly [];
                readonly consumedByArtifacts: readonly ["inventoryAlertWorkflow", "partsInventoryPage"];
            };
        };
    };
    export default notificationsModulePlan;
}
declare module "_102044_/l5/partInventory/module.defs" {
    export const partInventoryMdmModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmDomain";
        readonly artifactId: "partInventory";
        readonly moduleName: "partInventory";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdm";
            readonly moduleId: "partInventory";
            readonly domainId: "partInventory";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly domain: {
                readonly domainId: "partInventory";
                readonly title: "Peça e Estoque";
                readonly masterEntities: readonly ["Part", "InventoryStock"];
                readonly sourceOfTruth: "partInventoryMasterData";
                readonly consumers: readonly ["partsInventoryPage", "serviceOrderDetailPage", "inventoryAlertWorkflow", "inventoryAdjustUsecaseEntities", "serviceOrderUsecaseEntities", "metricTableOps", "inventoryLowStockMetric"];
                readonly governanceRules: readonly ["Cada peça deve ter código único e registro de estoque associado.", "Alerta operacional quando estoque abaixo do nível mínimo configurado.", "Baixa de estoque vinculada ao consumo em OS."];
            };
        };
    };
    export default partInventoryMdmModulePlan;
}
declare module "_102044_/l5/repairBay/module.defs" {
    export const modulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "module";
        readonly artifactId: "repairBay";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly module: {
                readonly moduleName: "repairBay";
                readonly purpose: "Organizar ordens de serviço e histórico de veículos com custos precisos, controle de peças e faturamento para oficinas mecânicas independentes.";
                readonly businessDomain: "Oficina mecânica independente";
                readonly languages: readonly ["pt-BR", "en"];
                readonly visualStyle: {
                    readonly tone: "Profissional e moderno";
                    readonly layout: "Limpo, focado em fluxo rápido de OS e histórico";
                    readonly palette: readonly ["#1F2937", "#374151", "#0EA5E9", "#10B981", "#F59E0B"];
                };
            };
            readonly actors: readonly [{
                readonly actorId: "shopOwner";
                readonly title: "Dono da oficina";
                readonly description: "Responsável por visão geral do negócio, faturamento e indicadores.";
            }, {
                readonly actorId: "attendant";
                readonly title: "Atendente";
                readonly description: "Registra clientes/veículos e cria/acompanha ordens de serviço.";
            }, {
                readonly actorId: "mechanic";
                readonly title: "Mecânico";
                readonly description: "Executa serviços, registra mão de obra e peças usadas na OS.";
            }];
            readonly capabilities: readonly [{
                readonly capabilityId: "manageCustomers";
                readonly title: "Gerenciar clientes";
                readonly description: "Cadastrar e manter dados de clientes e histórico associado.";
                readonly actor: "attendant";
                readonly priority: "now";
            }, {
                readonly capabilityId: "manageVehicles";
                readonly title: "Gerenciar veículos";
                readonly description: "Cadastrar veículos com marca/modelo/ano/placa/VIN e associar ao cliente.";
                readonly actor: "attendant";
                readonly priority: "now";
            }, {
                readonly capabilityId: "serviceOrderLifecycle";
                readonly title: "Criar e acompanhar OS";
                readonly description: "Criar OS, registrar itens de mão de obra e peças usadas, atualizar status e total.";
                readonly actor: "attendant";
                readonly priority: "now";
            }, {
                readonly capabilityId: "serviceOrderExecution";
                readonly title: "Executar serviços na OS";
                readonly description: "Registrar serviços executados, tempos e peças utilizadas na OS.";
                readonly actor: "mechanic";
                readonly priority: "now";
            }, {
                readonly capabilityId: "vehicleHistory";
                readonly title: "Histórico completo do veículo e cliente";
                readonly description: "Consultar histórico de serviços, peças e custos por veículo/cliente.";
                readonly actor: "shopOwner";
                readonly priority: "now";
            }, {
                readonly capabilityId: "partsInventoryControl";
                readonly title: "Controle de peças e estoque";
                readonly description: "Gerir peças, níveis de estoque e alertas de reposição.";
                readonly actor: "shopOwner";
                readonly priority: "now";
            }, {
                readonly capabilityId: "billingManagement";
                readonly title: "Faturamento";
                readonly description: "Gerar faturas vinculadas às OS e acompanhar valores.";
                readonly actor: "shopOwner";
                readonly priority: "now";
            }, {
                readonly capabilityId: "dashboardInsights";
                readonly title: "Dashboard operacional";
                readonly description: "Visualizar OS abertas, receita do mês e veículos com manutenção prevista.";
                readonly actor: "shopOwner";
                readonly priority: "now";
            }, {
                readonly capabilityId: "llmRepairSuggestions";
                readonly title: "IA para sugestões de reparo e tempo";
                readonly description: "Sugerir reparos comuns por modelo/ano e estimar tempo de mão de obra a partir da descrição.";
                readonly actor: "mechanic";
                readonly priority: "soon";
            }];
            readonly ontology: {
                readonly entities: {
                    readonly Customer: {
                        readonly title: "Cliente";
                        readonly description: "Pessoa ou empresa atendida pela oficina, vinculada a veículos e OS.";
                    };
                    readonly Vehicle: {
                        readonly title: "Veículo";
                        readonly description: "Veículo do cliente com dados de identificação e histórico de manutenção.";
                    };
                    readonly ServiceOrder: {
                        readonly title: "Ordem de Serviço";
                        readonly description: "Compromisso de execução de serviços e peças para um veículo, com custos e status.";
                    };
                    readonly LaborItem: {
                        readonly title: "Item de Mão de Obra";
                        readonly description: "Registro de serviço executado com tempo e custo associado à OS.";
                    };
                    readonly Part: {
                        readonly title: "Peça";
                        readonly description: "Item de estoque utilizado em reparos e OS.";
                    };
                    readonly InventoryStock: {
                        readonly title: "Estoque";
                        readonly description: "Níveis de peças disponíveis e parâmetros de reposição.";
                    };
                    readonly Invoice: {
                        readonly title: "Fatura";
                        readonly description: "Documento interno de cobrança associado a uma OS.";
                    };
                    readonly MaintenanceForecast: {
                        readonly title: "Manutenção Prevista";
                        readonly description: "Sinalização de manutenção futura com base em histórico e tempo/quilometragem.";
                    };
                    readonly RepairSuggestion: {
                        readonly title: "Sugestão de Reparo";
                        readonly description: "Resposta da IA com reparos comuns para modelo/ano e estimativa de tempo.";
                    };
                    readonly ServiceOrderCommand: {
                        readonly title: "Comando de OS";
                        readonly description: "Entidade de caso de uso para criação, atualização e fechamento da OS.";
                    };
                    readonly InventoryAdjustmentCommand: {
                        readonly title: "Comando de Ajuste de Estoque";
                        readonly description: "Entidade de caso de uso para ajuste de níveis e disparo de alertas.";
                    };
                    readonly InvoiceCommand: {
                        readonly title: "Comando de Fatura";
                        readonly description: "Entidade de caso de uso para geração e atualização de faturas.";
                    };
                    readonly MaintenanceForecastCommand: {
                        readonly title: "Comando de Manutenção Prevista";
                        readonly description: "Entidade de caso de uso para gerar/atualizar previsões de manutenção com base no histórico.";
                    };
                };
            };
            readonly rules: readonly [{
                readonly ruleId: "ruleServiceOrderStatus";
                readonly title: "Status da OS";
                readonly description: "A OS deve seguir um ciclo de vida padronizado: aberta → em execução → aguardando peça → concluída → fechada/cancelada.";
                readonly appliesTo: readonly ["ServiceOrder"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleServiceOrderTotal";
                readonly title: "Cálculo de total da OS";
                readonly description: "O total da OS é a soma de itens de mão de obra e peças usadas, com impostos/descontos configurados.";
                readonly appliesTo: readonly ["ServiceOrder", "LaborItem", "Part"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleVehicleCustomerLink";
                readonly title: "Vínculo veículo-cliente obrigatório";
                readonly description: "Todo veículo deve estar associado a um cliente ativo.";
                readonly appliesTo: readonly ["Vehicle", "Customer"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleInventoryLowStock";
                readonly title: "Alerta de estoque baixo";
                readonly description: "Quando o estoque estiver abaixo do nível mínimo configurado, deve ser gerado alerta operacional.";
                readonly appliesTo: readonly ["InventoryStock", "Part"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleInvoiceFromServiceOrder";
                readonly title: "Fatura vinculada à OS";
                readonly description: "Faturas devem ser geradas a partir de uma OS concluída e conter o total consolidado.";
                readonly appliesTo: readonly ["Invoice", "ServiceOrder"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleMaintenanceForecast";
                readonly title: "Manutenção prevista";
                readonly description: "Veículos com histórico de serviços recorrentes devem ser marcados com manutenção prevista.";
                readonly appliesTo: readonly ["MaintenanceForecast", "Vehicle", "ServiceOrder"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleRoleAccess";
                readonly title: "Acesso por perfil";
                readonly description: "Dono, atendente e mecânico possuem permissões distintas por funcionalidade.";
                readonly appliesTo: readonly ["Customer", "Vehicle", "ServiceOrder", "Invoice", "Part", "InventoryStock", "MaintenanceForecast"];
                readonly layer: "layer_2";
            }];
            readonly relationships: readonly [{
                readonly relationshipId: "relCustomerVehicle";
                readonly fromEntity: "Customer";
                readonly toEntity: "Vehicle";
                readonly type: "oneToMany";
                readonly description: "Cliente possui um ou mais veículos.";
            }, {
                readonly relationshipId: "relVehicleServiceOrder";
                readonly fromEntity: "Vehicle";
                readonly toEntity: "ServiceOrder";
                readonly type: "oneToMany";
                readonly description: "Veículo pode ter várias ordens de serviço.";
            }, {
                readonly relationshipId: "relServiceOrderLaborItem";
                readonly fromEntity: "ServiceOrder";
                readonly toEntity: "LaborItem";
                readonly type: "oneToMany";
                readonly description: "OS agrega itens de mão de obra.";
            }, {
                readonly relationshipId: "relServiceOrderPart";
                readonly fromEntity: "ServiceOrder";
                readonly toEntity: "Part";
                readonly type: "manyToMany";
                readonly description: "OS utiliza peças do estoque.";
            }, {
                readonly relationshipId: "relPartInventoryStock";
                readonly fromEntity: "Part";
                readonly toEntity: "InventoryStock";
                readonly type: "oneToOne";
                readonly description: "Cada peça possui um registro de estoque associado.";
            }, {
                readonly relationshipId: "relServiceOrderInvoice";
                readonly fromEntity: "ServiceOrder";
                readonly toEntity: "Invoice";
                readonly type: "oneToOne";
                readonly description: "OS gera uma fatura vinculada.";
            }, {
                readonly relationshipId: "relVehicleMaintenanceForecast";
                readonly fromEntity: "Vehicle";
                readonly toEntity: "MaintenanceForecast";
                readonly type: "oneToMany";
                readonly description: "Veículo pode ter previsões de manutenção.";
            }, {
                readonly relationshipId: "relServiceOrderCommand";
                readonly fromEntity: "ServiceOrderCommand";
                readonly toEntity: "ServiceOrder";
                readonly type: "writes";
                readonly description: "Comando de OS cria/atualiza a OS.";
            }, {
                readonly relationshipId: "relInventoryAdjustmentCommand";
                readonly fromEntity: "InventoryAdjustmentCommand";
                readonly toEntity: "InventoryStock";
                readonly type: "writes";
                readonly description: "Comando ajusta níveis de estoque e alerta.";
            }, {
                readonly relationshipId: "relInvoiceCommand";
                readonly fromEntity: "InvoiceCommand";
                readonly toEntity: "Invoice";
                readonly type: "writes";
                readonly description: "Comando gera ou atualiza fatura.";
            }, {
                readonly relationshipId: "relRepairSuggestionVehicle";
                readonly fromEntity: "RepairSuggestion";
                readonly toEntity: "Vehicle";
                readonly type: "manyToOne";
                readonly description: "Sugestão de reparo é contextualizada por veículo.";
            }, {
                readonly relationshipId: "relRepairSuggestionServiceOrder";
                readonly fromEntity: "RepairSuggestion";
                readonly toEntity: "ServiceOrder";
                readonly type: "optionalManyToOne";
                readonly description: "Sugestão pode estar vinculada a uma OS específica quando solicitada.";
            }, {
                readonly relationshipId: "relMaintenanceForecastCommand";
                readonly fromEntity: "MaintenanceForecastCommand";
                readonly toEntity: "MaintenanceForecast";
                readonly type: "writes";
                readonly description: "Comando gera/atualiza previsões de manutenção.";
            }];
            readonly userActions: readonly [{
                readonly actionId: "createCustomer";
                readonly title: "Cadastrar cliente";
                readonly actor: "attendant";
                readonly capabilityId: "manageCustomers";
                readonly description: "Criar registro de cliente com dados de contato.";
                readonly commandType: "create";
                readonly affectedEntities: readonly ["Customer"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "updateCustomer";
                readonly title: "Atualizar cliente";
                readonly actor: "attendant";
                readonly capabilityId: "manageCustomers";
                readonly description: "Editar dados do cliente.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["Customer"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "createVehicle";
                readonly title: "Cadastrar veículo";
                readonly actor: "attendant";
                readonly capabilityId: "manageVehicles";
                readonly description: "Cadastrar veículo com marca/modelo/ano/placa/VIN e vínculo ao cliente.";
                readonly commandType: "create";
                readonly affectedEntities: readonly ["Vehicle"];
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
            }, {
                readonly actionId: "updateVehicle";
                readonly title: "Atualizar veículo";
                readonly actor: "attendant";
                readonly capabilityId: "manageVehicles";
                readonly description: "Editar dados do veículo.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["Vehicle"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "createServiceOrder";
                readonly title: "Criar OS";
                readonly actor: "attendant";
                readonly capabilityId: "serviceOrderLifecycle";
                readonly description: "Criar OS para um veículo e cliente.";
                readonly commandType: "create";
                readonly affectedEntities: readonly ["ServiceOrder", "ServiceOrderCommand"];
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderStatus", "ruleRoleAccess"];
            }, {
                readonly actionId: "addLaborItem";
                readonly title: "Adicionar mão de obra";
                readonly actor: "mechanic";
                readonly capabilityId: "serviceOrderExecution";
                readonly description: "Registrar serviço executado com tempo e custo.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["LaborItem", "ServiceOrder", "ServiceOrderCommand"];
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
            }, {
                readonly actionId: "addPartToServiceOrder";
                readonly title: "Adicionar peça à OS";
                readonly actor: "mechanic";
                readonly capabilityId: "serviceOrderExecution";
                readonly description: "Registrar peça utilizada e baixar estoque.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["Part", "InventoryStock", "ServiceOrder", "ServiceOrderCommand", "InventoryAdjustmentCommand"];
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleInventoryLowStock", "ruleRoleAccess"];
            }, {
                readonly actionId: "updateServiceOrderStatus";
                readonly title: "Atualizar status da OS";
                readonly actor: "attendant";
                readonly capabilityId: "serviceOrderLifecycle";
                readonly description: "Mover OS pelo ciclo de vida até fechamento/cancelamento.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["ServiceOrder", "ServiceOrderCommand"];
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
            }, {
                readonly actionId: "closeServiceOrder";
                readonly title: "Fechar OS";
                readonly actor: "attendant";
                readonly capabilityId: "serviceOrderLifecycle";
                readonly description: "Confirmar conclusão e fechamento da OS.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["ServiceOrder", "ServiceOrderCommand"];
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
            }, {
                readonly actionId: "adjustInventory";
                readonly title: "Ajustar estoque";
                readonly actor: "shopOwner";
                readonly capabilityId: "partsInventoryControl";
                readonly description: "Atualizar níveis de estoque e mínimos por peça.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["InventoryStock", "InventoryAdjustmentCommand"];
                readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
            }, {
                readonly actionId: "generateInvoice";
                readonly title: "Gerar fatura";
                readonly actor: "shopOwner";
                readonly capabilityId: "billingManagement";
                readonly description: "Gerar fatura a partir da OS concluída.";
                readonly commandType: "create";
                readonly affectedEntities: readonly ["Invoice", "InvoiceCommand"];
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
            }, {
                readonly actionId: "updateInvoiceStatus";
                readonly title: "Atualizar status da fatura";
                readonly actor: "shopOwner";
                readonly capabilityId: "billingManagement";
                readonly description: "Atualizar status de faturamento interno.";
                readonly commandType: "update";
                readonly affectedEntities: readonly ["Invoice", "InvoiceCommand"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "viewVehicleHistory";
                readonly title: "Consultar histórico do veículo";
                readonly actor: "shopOwner";
                readonly capabilityId: "vehicleHistory";
                readonly description: "Visualizar histórico completo de serviços e custos do veículo e cliente.";
                readonly commandType: "read";
                readonly affectedEntities: readonly ["Vehicle", "Customer", "ServiceOrder", "Invoice"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "viewDashboard";
                readonly title: "Visualizar dashboard";
                readonly actor: "shopOwner";
                readonly capabilityId: "dashboardInsights";
                readonly description: "Acessar indicadores operacionais principais.";
                readonly commandType: "read";
                readonly affectedEntities: readonly ["ServiceOrder", "Invoice", "InventoryStock", "MaintenanceForecast"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly actionId: "requestRepairSuggestion";
                readonly title: "Solicitar sugestão de reparo";
                readonly actor: "mechanic";
                readonly capabilityId: "llmRepairSuggestions";
                readonly description: "Pedir à IA reparos comuns por modelo/ano ou estimativa de tempo de mão de obra.";
                readonly commandType: "read";
                readonly affectedEntities: readonly ["RepairSuggestion", "Vehicle", "ServiceOrder"];
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }];
            readonly approvedArtifacts: {
                readonly pages: readonly [{
                    readonly signal: "dashboardPage";
                    readonly title: "Dashboard";
                    readonly reason: "Visão rápida de OS abertas, receita do mês e manutenção prevista.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "page";
                    readonly references: readonly ["openServiceOrdersMetric", "monthlyRevenueMetric", "upcomingMaintenanceMetric", "inventoryLowStockMetric", "metricTableOps"];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly signal: "vehicleHistoryPage";
                    readonly title: "Histórico de Veículo e Cliente";
                    readonly reason: "Histórico completo por veículo/cliente é foco central do produto.";
                    readonly priority: "now";
                    readonly actor: "attendant";
                    readonly artifactType: "page";
                    readonly references: readonly ["Customer", "Vehicle", "ServiceOrder", "Invoice"];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly signal: "serviceOrderListPage";
                    readonly title: "Ordens de Serviço";
                    readonly reason: "Listagem e acesso rápido para criação e acompanhamento.";
                    readonly priority: "now";
                    readonly actor: "attendant";
                    readonly artifactType: "page";
                    readonly references: readonly ["ServiceOrder"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly signal: "serviceOrderDetailPage";
                    readonly title: "Detalhe da Ordem de Serviço";
                    readonly reason: "Registrar mão de obra, peças usadas, status e total.";
                    readonly priority: "now";
                    readonly actor: "mechanic";
                    readonly artifactType: "page";
                    readonly references: readonly ["ServiceOrder", "LaborItem", "Part"];
                    readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleServiceOrderStatus", "ruleRoleAccess"];
                }, {
                    readonly signal: "partsInventoryPage";
                    readonly title: "Controle de Peças/Estoque";
                    readonly reason: "Gestão de peças, níveis de estoque e alertas.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "page";
                    readonly references: readonly ["Part", "InventoryStock"];
                    readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
                }, {
                    readonly signal: "billingPage";
                    readonly title: "Faturamento";
                    readonly reason: "Gerar e acompanhar faturas por OS.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "page";
                    readonly references: readonly ["Invoice", "ServiceOrder"];
                    readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                }, {
                    readonly signal: "adminDashboardPage";
                    readonly title: "Administração do Painel";
                    readonly reason: "Configurar indicadores exibidos no painel básico do MVP.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "page";
                    readonly references: readonly ["shopOwnerMetricsDashboard"];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly signal: "customerManagementPage";
                    readonly title: "Cadastro de Clientes";
                    readonly reason: "CRUD dedicado para clientes, alinhado às ações de criação/edição.";
                    readonly priority: "now";
                    readonly actor: "attendant";
                    readonly artifactType: "page";
                    readonly references: readonly ["Customer"];
                    readonly rulesApplied: readonly ["ruleRoleAccess"];
                }, {
                    readonly signal: "vehicleManagementPage";
                    readonly title: "Cadastro de Veículos";
                    readonly reason: "CRUD dedicado para veículos com vínculo ao cliente.";
                    readonly priority: "now";
                    readonly actor: "attendant";
                    readonly artifactType: "page";
                    readonly references: readonly ["Vehicle", "Customer"];
                    readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
                }];
                readonly workflows: readonly [{
                    readonly signal: "serviceOrderWorkflow";
                    readonly title: "Fluxo da Ordem de Serviço";
                    readonly reason: "OS tem status e transições até fechamento.";
                    readonly priority: "now";
                    readonly actor: "attendant";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["ServiceOrder", "ServiceOrderCommand"];
                    readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal"];
                }, {
                    readonly signal: "inventoryAlertWorkflow";
                    readonly title: "Alerta de Estoque";
                    readonly reason: "Alertas de peças exigem regras e acionamento automático.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["InventoryAdjustmentCommand", "InventoryStock", "Part"];
                    readonly rulesApplied: readonly ["ruleInventoryLowStock"];
                }, {
                    readonly signal: "billingWorkflow";
                    readonly title: "Fluxo de Faturamento";
                    readonly reason: "Geração de fatura a partir da OS e controle de status.";
                    readonly priority: "soon";
                    readonly actor: "shopOwner";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["InvoiceCommand", "Invoice", "ServiceOrder"];
                    readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder"];
                }, {
                    readonly signal: "maintenanceForecastWorkflow";
                    readonly title: "Geração de Manutenção Prevista";
                    readonly reason: "Gerar e atualizar previsões de manutenção com base no histórico do veículo.";
                    readonly priority: "soon";
                    readonly actor: "shopOwner";
                    readonly artifactType: "workflow";
                    readonly references: readonly ["MaintenanceForecastCommand", "MaintenanceForecast", "Vehicle", "ServiceOrder"];
                    readonly rulesApplied: readonly ["ruleMaintenanceForecast"];
                }];
                readonly plugins: readonly [];
                readonly agents: readonly [{
                    readonly signal: "repairSuggestionAgent";
                    readonly title: "Agente de IA para reparos e tempo";
                    readonly reason: "Requisito de IA para sugerir reparos comuns e estimar tempo de mão de obra.";
                    readonly priority: "soon";
                    readonly actor: "mechanic";
                    readonly artifactType: "agent";
                    readonly references: readonly ["Vehicle", "ServiceOrder", "RepairSuggestion"];
                }];
                readonly horizontalModules: readonly [{
                    readonly signal: "i18nModule";
                    readonly title: "Internacionalização";
                    readonly reason: "Suporte obrigatório a pt-BR e en.";
                    readonly priority: "now";
                    readonly artifactType: "horizontalModule";
                    readonly references: readonly [];
                }, {
                    readonly signal: "authModule";
                    readonly title: "Autenticação e perfis";
                    readonly reason: "Perfis de dono, atendente e mecânico com permissões distintas.";
                    readonly priority: "now";
                    readonly artifactType: "horizontalModule";
                    readonly references: readonly ["ruleRoleAccess"];
                }, {
                    readonly signal: "notificationModule";
                    readonly title: "Notificações operacionais";
                    readonly reason: "Alertas de estoque baixo e eventos críticos de OS.";
                    readonly priority: "soon";
                    readonly artifactType: "horizontalModule";
                    readonly references: readonly ["inventoryAlertWorkflow"];
                }];
                readonly mdm: readonly [{
                    readonly signal: "customerMasterData";
                    readonly title: "MDM de Cliente";
                    readonly reason: "Entidade central para histórico e OS; precisa padronização.";
                    readonly priority: "now";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["Customer"];
                }, {
                    readonly signal: "vehicleMasterData";
                    readonly title: "MDM de Veículo";
                    readonly reason: "Veículo é o principal objeto do histórico e manutenção prevista.";
                    readonly priority: "now";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["Vehicle"];
                }, {
                    readonly signal: "serviceOrderMasterData";
                    readonly title: "MDM de Ordem de Serviço";
                    readonly reason: "OS é o núcleo do fluxo e do cálculo de custos.";
                    readonly priority: "now";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["ServiceOrder"];
                }, {
                    readonly signal: "partInventoryMasterData";
                    readonly title: "MDM de Peça/Estoque";
                    readonly reason: "Controle de peças e alertas depende de dados padronizados.";
                    readonly priority: "now";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["Part", "InventoryStock"];
                }, {
                    readonly signal: "invoiceMasterData";
                    readonly title: "MDM de Fatura";
                    readonly reason: "Faturamento exige registros consistentes vinculados à OS.";
                    readonly priority: "now";
                    readonly artifactType: "mdm";
                    readonly references: readonly ["Invoice"];
                }];
                readonly metricTables: readonly [{
                    readonly signal: "metricTableOps";
                    readonly title: "Tabela de métricas operacionais";
                    readonly reason: "Consolidar OS abertas, receita mensal e estoque baixo para o painel.";
                    readonly priority: "now";
                    readonly artifactType: "metricTable";
                    readonly references: readonly ["ServiceOrder", "Invoice", "InventoryStock"];
                }, {
                    readonly signal: "openServiceOrdersMetric";
                    readonly title: "Métrica de OS abertas";
                    readonly reason: "Indicador de volume atual de ordens abertas no painel.";
                    readonly priority: "now";
                    readonly artifactType: "metric";
                    readonly references: readonly ["metricTableOps"];
                }, {
                    readonly signal: "monthlyRevenueMetric";
                    readonly title: "Métrica de receita mensal";
                    readonly reason: "Indicador de receita consolidada no mês no painel.";
                    readonly priority: "now";
                    readonly artifactType: "metric";
                    readonly references: readonly ["metricTableOps"];
                }, {
                    readonly signal: "upcomingMaintenanceMetric";
                    readonly title: "Métrica de manutenção prevista";
                    readonly reason: "Indicador de veículos com manutenção prevista.";
                    readonly priority: "now";
                    readonly artifactType: "metric";
                    readonly references: readonly ["MaintenanceForecast", "metricTableOps"];
                }, {
                    readonly signal: "inventoryLowStockMetric";
                    readonly title: "Métrica de estoque baixo";
                    readonly reason: "Indicador de itens abaixo do mínimo.";
                    readonly priority: "now";
                    readonly artifactType: "metric";
                    readonly references: readonly ["InventoryStock", "metricTableOps"];
                }];
                readonly metricDashboards: readonly [{
                    readonly signal: "shopOwnerMetricsDashboard";
                    readonly title: "Dashboard de métricas do dono da oficina";
                    readonly reason: "Painel básico do MVP com indicadores principais.";
                    readonly priority: "now";
                    readonly actor: "shopOwner";
                    readonly artifactType: "metricDashboard";
                    readonly references: readonly ["metricTableOps", "openServiceOrdersMetric", "monthlyRevenueMetric", "upcomingMaintenanceMetric", "inventoryLowStockMetric"];
                }];
                readonly usecaseEntities: readonly [{
                    readonly signal: "serviceOrderUsecaseEntities";
                    readonly title: "Entidades de caso de uso da OS";
                    readonly reason: "Operações de criação/atualização de OS, itens e total.";
                    readonly priority: "now";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["ServiceOrderCommand", "LaborItem", "Part", "ServiceOrder"];
                }, {
                    readonly signal: "inventoryAdjustUsecaseEntities";
                    readonly title: "Entidades de caso de uso de estoque";
                    readonly reason: "Ajuste de estoque e disparo de alertas.";
                    readonly priority: "now";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["InventoryAdjustmentCommand", "InventoryStock"];
                }, {
                    readonly signal: "invoiceUsecaseEntities";
                    readonly title: "Entidades de caso de uso de fatura";
                    readonly reason: "Geração e atualização de faturas vinculadas à OS.";
                    readonly priority: "now";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["InvoiceCommand", "Invoice", "ServiceOrder"];
                }, {
                    readonly signal: "maintenanceForecastUsecaseEntities";
                    readonly title: "Entidades de caso de uso de manutenção prevista";
                    readonly reason: "Geração e atualização de previsões de manutenção.";
                    readonly priority: "soon";
                    readonly artifactType: "usecaseEntity";
                    readonly references: readonly ["MaintenanceForecastCommand", "MaintenanceForecast", "Vehicle", "ServiceOrder"];
                }];
            };
            readonly decisions: readonly [{
                readonly decisionId: "decisionMdmCustomer";
                readonly title: "MDM de Cliente";
                readonly decision: "Aceito";
                readonly reason: "Cliente é entidade central para histórico e faturamento; padronização é obrigatória.";
                readonly affectedArtifacts: readonly ["customerMasterData"];
            }, {
                readonly decisionId: "decisionMdmVehicle";
                readonly title: "MDM de Veículo";
                readonly decision: "Aceito";
                readonly reason: "Veículo é o núcleo do histórico e manutenção prevista.";
                readonly affectedArtifacts: readonly ["vehicleMasterData"];
            }, {
                readonly decisionId: "decisionMdmServiceOrder";
                readonly title: "MDM de Ordem de Serviço";
                readonly decision: "Aceito";
                readonly reason: "Fluxo rápido de OS e custo preciso dependem da OS bem definida.";
                readonly affectedArtifacts: readonly ["serviceOrderMasterData"];
            }, {
                readonly decisionId: "decisionMdmPartInventory";
                readonly title: "MDM de Peça/Estoque";
                readonly decision: "Aceito";
                readonly reason: "Controle de peças com alertas requer estrutura consistente.";
                readonly affectedArtifacts: readonly ["partInventoryMasterData"];
            }, {
                readonly decisionId: "decisionMdmInvoice";
                readonly title: "MDM de Fatura";
                readonly decision: "Aceito";
                readonly reason: "Faturamento é requisito do MVP.";
                readonly affectedArtifacts: readonly ["invoiceMasterData"];
            }, {
                readonly decisionId: "decisionUsecaseServiceOrderOps";
                readonly title: "Entidades de caso de uso da OS";
                readonly decision: "Aceito";
                readonly reason: "Há operações de escrita e atualização de custos e status.";
                readonly affectedArtifacts: readonly ["serviceOrderUsecaseEntities"];
            }, {
                readonly decisionId: "decisionUsecaseInventoryAdjust";
                readonly title: "Entidades de caso de uso de estoque";
                readonly decision: "Aceito";
                readonly reason: "Controle de peças com alertas exige comandos e sinais de backend.";
                readonly affectedArtifacts: readonly ["inventoryAdjustUsecaseEntities"];
            }, {
                readonly decisionId: "decisionWorkflowServiceOrder";
                readonly title: "Workflow de Ordem de Serviço";
                readonly decision: "Aceito";
                readonly reason: "OS tem ciclo de vida e transições claras.";
                readonly affectedArtifacts: readonly ["serviceOrderWorkflow"];
            }, {
                readonly decisionId: "decisionWorkflowInventoryAlert";
                readonly title: "Workflow de Alerta de Estoque";
                readonly decision: "Aceito";
                readonly reason: "Alertas são prioridade do MVP.";
                readonly affectedArtifacts: readonly ["inventoryAlertWorkflow"];
            }, {
                readonly decisionId: "decisionWorkflowBilling";
                readonly title: "Workflow de Faturamento";
                readonly decision: "Aceito";
                readonly reason: "Faturamento é necessário e depende do escopo fiscal.";
                readonly affectedArtifacts: readonly ["billingWorkflow"];
            }, {
                readonly decisionId: "decisionPageDashboard";
                readonly title: "Dashboard operacional";
                readonly decision: "Aceito";
                readonly reason: "Painel básico foi aceito para o MVP.";
                readonly affectedArtifacts: readonly ["dashboardPage", "shopOwnerMetricsDashboard"];
            }, {
                readonly decisionId: "decisionPageVehicleHistory";
                readonly title: "Histórico de Veículo e Cliente";
                readonly decision: "Aceito";
                readonly reason: "Histórico é foco central do produto.";
                readonly affectedArtifacts: readonly ["vehicleHistoryPage"];
            }, {
                readonly decisionId: "decisionPageServiceOrderList";
                readonly title: "Lista de Ordens de Serviço";
                readonly decision: "Aceito";
                readonly reason: "Fluxo rápido de OS é requisito.";
                readonly affectedArtifacts: readonly ["serviceOrderListPage"];
            }, {
                readonly decisionId: "decisionPageServiceOrderDetail";
                readonly title: "Detalhe da Ordem de Serviço";
                readonly decision: "Aceito";
                readonly reason: "Execução de serviços e cálculo de custos precisam de interface dedicada.";
                readonly affectedArtifacts: readonly ["serviceOrderDetailPage"];
            }, {
                readonly decisionId: "decisionPagePartsInventory";
                readonly title: "Controle de Peças/Estoque";
                readonly decision: "Aceito";
                readonly reason: "Prioridade declarada para controle de peças com alertas.";
                readonly affectedArtifacts: readonly ["partsInventoryPage"];
            }, {
                readonly decisionId: "decisionPageBilling";
                readonly title: "Faturamento";
                readonly decision: "Aceito";
                readonly reason: "Faturamento é parte das telas-chave.";
                readonly affectedArtifacts: readonly ["billingPage"];
            }, {
                readonly decisionId: "decisionAgentRepairSuggestion";
                readonly title: "Agente de IA para sugestões de reparos e tempo";
                readonly decision: "Aceito";
                readonly reason: "Funcionalidade de IA é desejada após o núcleo operacional.";
                readonly affectedArtifacts: readonly ["repairSuggestionAgent"];
            }, {
                readonly decisionId: "decisionHorizontalI18n";
                readonly title: "Internacionalização";
                readonly decision: "Aceito";
                readonly reason: "Bilíngue é requisito explícito.";
                readonly affectedArtifacts: readonly ["i18nModule"];
            }, {
                readonly decisionId: "decisionHorizontalAuth";
                readonly title: "Autenticação e perfis";
                readonly decision: "Aceito";
                readonly reason: "Papéis foram definidos e exigem controle de acesso.";
                readonly affectedArtifacts: readonly ["authModule"];
            }, {
                readonly decisionId: "decisionNotificationInventory";
                readonly title: "Notificações operacionais";
                readonly decision: "Aceito";
                readonly reason: "Alertas requerem comunicação operacional consistente.";
                readonly affectedArtifacts: readonly ["notificationModule"];
            }, {
                readonly decisionId: "decisionMetricTableOps";
                readonly title: "Tabela de métricas operacionais";
                readonly decision: "Aceito";
                readonly reason: "Painel básico do MVP requer métricas consolidadas.";
                readonly affectedArtifacts: readonly ["metricTableOps"];
            }, {
                readonly decisionId: "decisionShopOwnerDashboardMetrics";
                readonly title: "Dashboard de métricas do dono da oficina";
                readonly decision: "Aceito";
                readonly reason: "MVP inclui painel básico com indicadores principais.";
                readonly affectedArtifacts: readonly ["shopOwnerMetricsDashboard"];
            }];
            readonly deferredItems: readonly [];
        };
    };
    export default modulePlan;
}
declare module "_102044_/l5/repairBay/rules.defs" {
    export const rulesPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "rules";
        readonly artifactId: "repairBayRules";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentFinalizeSolutionPlan";
            readonly stepId: 11;
            readonly planId: "plan-finalize-solution-plan";
        };
        readonly data: {
            readonly moduleName: "repairBay";
            readonly rules: readonly [{
                readonly ruleId: "ruleServiceOrderStatus";
                readonly title: "Status da OS";
                readonly description: "A OS deve seguir um ciclo de vida padronizado: aberta → em execução → aguardando peça → concluída → fechada/cancelada.";
                readonly appliesTo: readonly ["ServiceOrder"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleServiceOrderTotal";
                readonly title: "Cálculo de total da OS";
                readonly description: "O total da OS é a soma de itens de mão de obra e peças usadas, com impostos/descontos configurados.";
                readonly appliesTo: readonly ["ServiceOrder", "LaborItem", "Part"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleVehicleCustomerLink";
                readonly title: "Vínculo veículo-cliente obrigatório";
                readonly description: "Todo veículo deve estar associado a um cliente ativo.";
                readonly appliesTo: readonly ["Vehicle", "Customer"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleInventoryLowStock";
                readonly title: "Alerta de estoque baixo";
                readonly description: "Quando o estoque estiver abaixo do nível mínimo configurado, deve ser gerado alerta operacional.";
                readonly appliesTo: readonly ["InventoryStock", "Part"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleInvoiceFromServiceOrder";
                readonly title: "Fatura vinculada à OS";
                readonly description: "Faturas devem ser geradas a partir de uma OS concluída e conter o total consolidado.";
                readonly appliesTo: readonly ["Invoice", "ServiceOrder"];
                readonly layer: "layer_1";
            }, {
                readonly ruleId: "ruleMaintenanceForecast";
                readonly title: "Manutenção prevista";
                readonly description: "Veículos com histórico de serviços recorrentes devem ser marcados com manutenção prevista.";
                readonly appliesTo: readonly ["MaintenanceForecast", "Vehicle", "ServiceOrder"];
                readonly layer: "layer_2";
            }, {
                readonly ruleId: "ruleRoleAccess";
                readonly title: "Acesso por perfil";
                readonly description: "Dono, atendente e mecânico possuem permissões distintas por funcionalidade.";
                readonly appliesTo: readonly ["Customer", "Vehicle", "ServiceOrder", "Invoice", "Part", "InventoryStock", "MaintenanceForecast"];
                readonly layer: "layer_2";
            }];
        };
    };
    export default rulesPlan;
}
declare module "_102044_/l5/serviceOrder/module.defs" {
    export const serviceOrderMdmModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmDomain";
        readonly artifactId: "serviceOrder";
        readonly moduleName: "serviceOrder";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdm";
            readonly moduleId: "serviceOrder";
            readonly domainId: "serviceOrder";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly domain: {
                readonly domainId: "serviceOrder";
                readonly title: "Ordem de Serviço";
                readonly masterEntities: readonly ["ServiceOrder"];
                readonly sourceOfTruth: "serviceOrderMasterData";
                readonly consumers: readonly ["serviceOrderListPage", "serviceOrderDetailPage", "billingPage", "vehicleHistoryPage", "serviceOrderWorkflow", "serviceOrderUsecaseEntities", "invoiceUsecaseEntities", "billingWorkflow", "metricTableOps", "repairSuggestionAgent", "maintenanceForecastWorkflow", "maintenanceForecastUsecaseEntities"];
                readonly governanceRules: readonly ["Ciclo de vida padronizado: aberta → em execução → aguardando peça → concluída → fechada/cancelada.", "Total calculado pela soma de mão de obra e peças, com impostos/descontos configuráveis.", "Fechamento permitido apenas após conclusão dos serviços."];
            };
        };
    };
    export default serviceOrderMdmModulePlan;
}
declare module "_102044_/l5/vehicle/module.defs" {
    export const vehicleMdmModulePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "mdmDomain";
        readonly artifactId: "vehicle";
        readonly moduleName: "vehicle";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMDM";
            readonly stepId: 12;
            readonly planId: "plan-mdm";
        };
        readonly data: {
            readonly kind: "mdm";
            readonly moduleId: "vehicle";
            readonly domainId: "vehicle";
            readonly plannedByModule: "repairBay";
            readonly referencesExisting: false;
            readonly domain: {
                readonly domainId: "vehicle";
                readonly title: "Veículo";
                readonly masterEntities: readonly ["Vehicle"];
                readonly sourceOfTruth: "vehicleMasterData";
                readonly consumers: readonly ["vehicleManagementPage", "vehicleHistoryPage", "maintenanceForecastWorkflow", "maintenanceForecastUsecaseEntities", "repairSuggestionAgent"];
                readonly governanceRules: readonly ["Veículo deve estar vinculado a um cliente ativo.", "Identificação única por placa ou VIN.", "Dados de veículo são consumidos por OS, histórico e manutenção prevista."];
            };
        };
    };
    export default vehicleMdmModulePlan;
}
