declare module "_102044_/l1/repairBay/layer_1_external/inventoryAdjustmentCommandLog.defs" {
    export const inventoryAdjustmentCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryAdjustmentCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryAdjustmentCommandLog";
                readonly tableName: "inventory_adjustment_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Ajuste de Estoque";
                readonly purpose: "Registrar comandos de ajuste e baixa de estoque para auditoria e alertas.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryAdjustmentCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventory_adjustment_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de ajuste de estoque.";
                }, {
                    readonly name: "command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador do comando de ajuste.";
                }, {
                    readonly name: "inventory_stock_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao estoque ajustado.";
                }, {
                    readonly name: "part_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à peça ajustada.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada ao ajuste, quando aplicável.";
                }, {
                    readonly name: "command_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Tipo do comando (entrada, saída, correção, baixa).";
                }, {
                    readonly name: "quantity_delta";
                    readonly type: "decimal";
                    readonly nullable: false;
                    readonly description: "Variação aplicada ao estoque.";
                }, {
                    readonly name: "previous_quantity";
                    readonly type: "decimal";
                    readonly nullable: true;
                    readonly description: "Quantidade antes do ajuste.";
                }, {
                    readonly name: "new_quantity";
                    readonly type: "decimal";
                    readonly nullable: true;
                    readonly description: "Quantidade após o ajuste.";
                }, {
                    readonly name: "reason_code";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Motivo do ajuste para auditoria.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status do comando (registrado, aplicado, revertido, falhou).";
                }, {
                    readonly name: "actor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador do usuário que executou o ajuste.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou o ajuste.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora do evento de ajuste.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data e hora de criação do log.";
                }];
                readonly primaryKey: readonly ["inventory_adjustment_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventory_stock_id";
                    readonly targetEntity: "InventoryStock";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Estoque ajustado vinculado ao log.";
                }, {
                    readonly fieldName: "part_id";
                    readonly targetEntity: "Part";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Peça ajustada para consultas e alertas.";
                }, {
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular ajustes originados por ordens de serviço.";
                }, {
                    readonly fieldName: "command_id";
                    readonly targetEntity: "InventoryAdjustmentCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vínculo com o comando de ajuste registrado.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_adjustment_log_command";
                    readonly columns: readonly ["command_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por comando e auditoria.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_stock";
                    readonly columns: readonly ["inventory_stock_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por estoque e período para alertas.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_part";
                    readonly columns: readonly ["part_id", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por peça e período.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_status";
                    readonly columns: readonly ["status", "occurred_at"];
                    readonly unique: false;
                    readonly reason: "Monitorar falhas e reversões.";
                }, {
                    readonly indexName: "idx_inventory_adjustment_log_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear ajustes associados à OS.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payload completo do comando e contexto operacional.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["inventoryAdjustmentVolume", "inventoryAdjustmentFailures"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryAdjustmentCommandLog.defs.ts";
                readonly exportName: "inventoryAdjustmentCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryAdjustmentCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/inventoryMetrics.defs" {
    export const inventoryMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "inventoryMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 46;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "inventoryMetrics";
                readonly tableName: "inventory_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Estoque";
                readonly purpose: "Monitorar níveis de estoque, alertas de reposição e movimentações.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data e hora do evento de estoque.";
                }, {
                    readonly name: "part_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Identificador da peça relacionada.";
                }, {
                    readonly name: "command_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Tipo de movimentação de estoque.";
                }, {
                    readonly name: "is_low_stock";
                    readonly type: "boolean";
                    readonly nullable: false;
                    readonly default: false;
                    readonly description: "Indicador de estoque abaixo do mínimo.";
                }, {
                    readonly name: "stock_level";
                    readonly type: "numeric(12,2)";
                    readonly nullable: true;
                    readonly description: "Nível atual de estoque.";
                }, {
                    readonly name: "low_stock_count";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly default: 0;
                    readonly description: "Contagem de itens com estoque baixo no evento.";
                }, {
                    readonly name: "adjustment_volume";
                    readonly type: "numeric(12,2)";
                    readonly nullable: true;
                    readonly default: 0;
                    readonly description: "Volume total de ajustes no evento.";
                }, {
                    readonly name: "inventory_stock_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Referência ao estoque associado ao evento.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada ao ajuste, quando aplicável.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou a movimentação.";
                }, {
                    readonly name: "actor_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Usuário que executou a movimentação, quando disponível.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "partId";
                    readonly column: "part_id";
                    readonly type: "uuid";
                    readonly description: "Peça relacionada";
                }, {
                    readonly dimensionId: "commandType";
                    readonly column: "command_type";
                    readonly type: "text";
                    readonly description: "Tipo de movimentação";
                }, {
                    readonly dimensionId: "isLowStock";
                    readonly column: "is_low_stock";
                    readonly type: "boolean";
                    readonly description: "Indicador de estoque abaixo do mínimo";
                }];
                readonly measures: readonly [{
                    readonly measureId: "stockLevel";
                    readonly column: "stock_level";
                    readonly aggregation: "last";
                    readonly unit: "units";
                    readonly description: "Nível atual de estoque";
                }, {
                    readonly measureId: "lowStockCount";
                    readonly column: "low_stock_count";
                    readonly aggregation: "sum";
                    readonly description: "Contagem de itens com estoque baixo";
                }, {
                    readonly measureId: "adjustmentVolume";
                    readonly column: "adjustment_volume";
                    readonly aggregation: "sum";
                    readonly unit: "units";
                    readonly description: "Volume total de ajustes";
                }];
                readonly sourceWriteEvents: readonly ["adjustInventory", "addPartToServiceOrder"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_inventory_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Acelerar consultas por período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_part_time";
                        readonly columns: readonly ["part_id", "event_at"];
                        readonly purpose: "Filtrar métricas por peça e período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_command_time";
                        readonly columns: readonly ["command_type", "event_at"];
                        readonly purpose: "Filtrar métricas por tipo de movimentação e período.";
                    }, {
                        readonly indexName: "idx_inventory_metrics_low_stock_time";
                        readonly columns: readonly ["is_low_stock", "event_at"];
                        readonly purpose: "Monitorar eventos de estoque baixo por período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["inventoryAdjustUsecaseEntities", "serviceOrderUsecaseEntities"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInventoryLowStock"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryMetrics.defs.ts";
                readonly exportName: "inventoryMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/invoiceMetrics.defs" {
    export const invoiceMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "invoiceMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "invoiceMetrics";
                readonly tableName: "invoice_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Faturamento";
                readonly purpose: "Consolidar receita e status de faturamento ao longo do tempo.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de faturamento agregado.";
                }, {
                    readonly name: "invoice_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da fatura.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "OS vinculada.";
                }, {
                    readonly name: "invoice_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de faturas no intervalo.";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Receita total faturada no intervalo (BRL).";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "invoiceStatus";
                    readonly column: "invoice_status";
                    readonly type: "text";
                    readonly description: "Status da fatura";
                }, {
                    readonly dimensionId: "serviceOrderId";
                    readonly column: "service_order_id";
                    readonly type: "uuid";
                    readonly description: "OS vinculada";
                }];
                readonly measures: readonly [{
                    readonly measureId: "invoiceCount";
                    readonly column: "invoice_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de faturas";
                }, {
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total faturada";
                }];
                readonly sourceWriteEvents: readonly ["generateInvoice", "updateInvoiceStatus"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 anos";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_invoice_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Ordenação e consultas por tempo.";
                    }, {
                        readonly indexName: "idx_invoice_metrics_status_time";
                        readonly columns: readonly ["invoice_status", "event_at"];
                        readonly purpose: "Filtros por status e período.";
                    }, {
                        readonly indexName: "idx_invoice_metrics_service_order_time";
                        readonly columns: readonly ["service_order_id", "event_at"];
                        readonly purpose: "Filtros por OS e período.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["generateInvoice", "updateInvoiceStatus"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/invoiceMetrics.defs.ts";
                readonly exportName: "invoiceMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default invoiceMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/laborItem.defs" {
    export const laborItemTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "laborItem";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "laborItem";
                readonly tableName: "labor_item";
                readonly moduleId: "repairBay";
                readonly title: "Itens de Mão de Obra";
                readonly purpose: "Registrar serviços executados na OS com tempo e custo para cálculo do total e histórico.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "LaborItem";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "labor_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do item de mão de obra.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência à OS vinculada.";
                }, {
                    readonly name: "description";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Descrição do serviço executado.";
                }, {
                    readonly name: "labor_code";
                    readonly type: "varchar(50)";
                    readonly nullable: true;
                    readonly description: "Código interno do serviço, quando aplicável.";
                }, {
                    readonly name: "hours_worked";
                    readonly type: "numeric(10,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Horas trabalhadas no serviço.";
                }, {
                    readonly name: "hourly_rate";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor por hora aplicado ao serviço.";
                }, {
                    readonly name: "labor_total";
                    readonly type: "numeric(12,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total calculado do item de mão de obra.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly default: "pending";
                    readonly description: "Status do item de mão de obra.";
                }, {
                    readonly name: "performed_at";
                    readonly type: "timestamptz";
                    readonly nullable: true;
                    readonly description: "Data/hora de execução do serviço.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora da última atualização.";
                }];
                readonly primaryKey: readonly ["labor_item_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular itens de mão de obra à OS para cálculo de total e histórico.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_labor_item_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly reason: "Consulta de itens por OS nas telas de detalhe.";
                }, {
                    readonly indexName: "idx_labor_item_status";
                    readonly columns: readonly ["status"];
                    readonly reason: "Filtrar itens por status no fluxo da OS.";
                }, {
                    readonly indexName: "idx_labor_item_performed_at";
                    readonly columns: readonly ["performed_at"];
                    readonly reason: "Ordenação e filtros por data de execução no histórico do veículo.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/laborItem.defs.ts";
                readonly exportName: "laborItemTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default laborItemTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecast.defs" {
    export const maintenanceForecastTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "maintenanceForecast";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "maintenanceForecast";
                readonly tableName: "maintenance_forecast";
                readonly moduleId: "repairBay";
                readonly title: "Manutenções Previstas";
                readonly purpose: "Armazenar previsões de manutenção por veículo para consulta e métricas operacionais.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MaintenanceForecast";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "maintenance_forecast_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador da manutenção prevista.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Referência ao veículo MDM.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Ordem de serviço associada que originou a previsão.";
                }, {
                    readonly name: "forecast_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data prevista para a manutenção.";
                }, {
                    readonly name: "forecast_mileage_km";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Quilometragem prevista para a manutenção.";
                }, {
                    readonly name: "forecast_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo de manutenção prevista (ex.: troca de óleo).";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status da previsão (active, completed, cancelled).";
                }, {
                    readonly name: "confidence_score";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Nível de confiança da previsão.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Última atualização do registro.";
                }];
                readonly primaryKey: readonly ["maintenance_forecast_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "vehicle_id";
                    readonly targetEntity: "Vehicle";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular previsão ao veículo do cliente.";
                }, {
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Relacionar previsão ao histórico de OS quando aplicável.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "ix_maintenance_forecast_vehicle";
                    readonly columns: readonly ["vehicle_id"];
                    readonly unique: false;
                    readonly reason: "Consulta por veículo no histórico e dashboard.";
                }, {
                    readonly indexName: "ix_maintenance_forecast_status_date";
                    readonly columns: readonly ["status", "forecast_date"];
                    readonly unique: false;
                    readonly reason: "Filtrar previsões ativas por data para dashboard.";
                }, {
                    readonly indexName: "ix_maintenance_forecast_service_order";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Localizar previsão associada à OS.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["upcomingMaintenanceMetric"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecast.defs.ts";
                readonly exportName: "maintenanceForecastTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecastCommandLog.defs" {
    export const maintenanceForecastCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "maintenanceForecastCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 42;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "maintenanceForecastCommandLog";
                readonly tableName: "maintenance_forecast_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Comandos de Manutenção Prevista";
                readonly purpose: "Registrar comandos de geração/atualização de previsões.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "MaintenanceForecastCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "maintenance_forecast_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de comando.";
                }, {
                    readonly name: "maintenance_forecast_command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Comando de manutenção prevista relacionado.";
                }, {
                    readonly name: "maintenance_forecast_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Previsão de manutenção afetada.";
                }, {
                    readonly name: "command_type";
                    readonly type: "varchar(50)";
                    readonly nullable: false;
                    readonly description: "Tipo do comando (ex.: gerar, atualizar, recalcular).";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Status do comando no momento do log.";
                }, {
                    readonly name: "requested_by_role";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly description: "Perfil que solicitou a ação.";
                }, {
                    readonly name: "requested_by_user_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Usuário solicitante (quando disponível).";
                }, {
                    readonly name: "correlation_id";
                    readonly type: "varchar(80)";
                    readonly nullable: true;
                    readonly description: "Identificador de correlação do workflow.";
                }, {
                    readonly name: "attempt_number";
                    readonly type: "int";
                    readonly nullable: false;
                    readonly default: 1;
                    readonly description: "Número da tentativa de execução.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora do evento registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Data/hora de criação do log.";
                }];
                readonly primaryKey: readonly ["maintenance_forecast_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "maintenance_forecast_command_id";
                    readonly targetEntity: "MaintenanceForecastCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Vínculo ao comando executado.";
                }, {
                    readonly fieldName: "maintenance_forecast_id";
                    readonly targetEntity: "MaintenanceForecast";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Rastrear a previsão gerada/atualizada.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_mf_cmd_log_command_id";
                    readonly columns: readonly ["maintenance_forecast_command_id"];
                    readonly reason: "Busca de logs por comando.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_forecast_id";
                    readonly columns: readonly ["maintenance_forecast_id"];
                    readonly reason: "Consulta por previsão afetada.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_status_time";
                    readonly columns: readonly ["status", "occurred_at"];
                    readonly reason: "Filtrar eventos por status e período.";
                }, {
                    readonly indexName: "idx_mf_cmd_log_correlation";
                    readonly columns: readonly ["correlation_id"];
                    readonly reason: "Rastreio por correlação de workflow.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payload do comando e diagnósticos não filtrados com frequência.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecastCommandLog.defs.ts";
                readonly exportName: "maintenanceForecastCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/maintenanceForecastMetrics.defs" {
    export const maintenanceForecastMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "maintenanceForecastMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 48;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "maintenanceForecastMetrics";
                readonly tableName: "maintenance_forecast_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Manutenção Prevista";
                readonly purpose: "Rastrear previsões de manutenção e veículos com serviços pendentes futuros.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de métrica.";
                }, {
                    readonly name: "forecast_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da previsão.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo da previsão.";
                }, {
                    readonly name: "forecast_type";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Tipo de manutenção prevista.";
                }, {
                    readonly name: "forecast_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de previsões ativas.";
                }, {
                    readonly name: "upcoming_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Contagem de manutenções previstas para o período.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "forecastStatus";
                    readonly column: "forecast_status";
                    readonly type: "text";
                    readonly description: "Status da previsão";
                }, {
                    readonly dimensionId: "vehicleId";
                    readonly column: "vehicle_id";
                    readonly type: "uuid";
                    readonly description: "Veículo da previsão";
                }, {
                    readonly dimensionId: "forecastType";
                    readonly column: "forecast_type";
                    readonly type: "text";
                    readonly description: "Tipo de manutenção prevista";
                }];
                readonly measures: readonly [{
                    readonly measureId: "forecastCount";
                    readonly column: "forecast_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de previsões ativas";
                }, {
                    readonly measureId: "upcomingCount";
                    readonly column: "upcoming_count";
                    readonly aggregation: "sum";
                    readonly description: "Contagem de manutenções previstas para o período";
                }];
                readonly sourceWriteEvents: readonly ["maintenanceForecastCommand"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_maintenance_forecast_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Ordenação e consultas por tempo.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_status_time";
                        readonly columns: readonly ["forecast_status", "event_at"];
                        readonly purpose: "Filtros por status e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_vehicle_time";
                        readonly columns: readonly ["vehicle_id", "event_at"];
                        readonly purpose: "Filtros por veículo e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_maintenance_forecast_metrics_type_time";
                        readonly columns: readonly ["forecast_type", "event_at"];
                        readonly purpose: "Filtros por tipo e período.";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["maintenanceForecastWorkflow", "maintenanceForecastUsecaseEntities"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleMaintenanceForecast"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/maintenanceForecastMetrics.defs.ts";
                readonly exportName: "maintenanceForecastMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default maintenanceForecastMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/repairSuggestion.defs" {
    export const repairSuggestionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "repairSuggestion";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "repairSuggestion";
                readonly tableName: "repair_suggestion";
                readonly moduleId: "repairBay";
                readonly title: "Sugestões de Reparo";
                readonly purpose: "Guardar respostas da IA para reparos comuns e estimativas por veículo/OS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "RepairSuggestion";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "repairSuggestionId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da sugestão de reparo.";
                }, {
                    readonly name: "serviceOrderId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "OS relacionada à sugestão.";
                }, {
                    readonly name: "vehicleId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo relacionado à sugestão.";
                }, {
                    readonly name: "suggestionStatus";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly default: "active";
                    readonly description: "Status da sugestão (active, superseded, discarded).";
                }, {
                    readonly name: "suggestionDate";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly description: "Data de referência usada na sugestão (ex.: data da OS).";
                }, {
                    readonly name: "createdAt";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora de criação.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "timestamp";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora da última atualização.";
                }];
                readonly primaryKey: readonly ["repairSuggestionId"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "serviceOrderId";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular a sugestão à OS.";
                }, {
                    readonly fieldName: "vehicleId";
                    readonly targetEntity: "Vehicle";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Vincular a sugestão ao veículo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_repair_suggestion_service_order";
                    readonly columns: readonly ["serviceOrderId", "suggestionStatus"];
                    readonly unique: false;
                    readonly reason: "Busca por sugestão ativa da OS.";
                }, {
                    readonly indexName: "idx_repair_suggestion_vehicle";
                    readonly columns: readonly ["vehicleId", "suggestionDate"];
                    readonly unique: false;
                    readonly reason: "Consulta por histórico de sugestões do veículo.";
                }, {
                    readonly indexName: "idx_repair_suggestion_created_at";
                    readonly columns: readonly ["createdAt"];
                    readonly unique: false;
                    readonly reason: "Ordenação por data para listagens recentes.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "RepairSuggestionDetails";
                    readonly reason: "Armazena conteúdo completo da resposta da IA e estimativas detalhadas.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/repairSuggestion.defs.ts";
                readonly exportName: "repairSuggestionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default repairSuggestionTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/serviceOrderCommandLog.defs" {
    export const serviceOrderCommandLogTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "serviceOrderCommandLog";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 44;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "serviceOrderCommandLog";
                readonly tableName: "service_order_command_log";
                readonly moduleId: "repairBay";
                readonly title: "Logs de Comandos de OS";
                readonly purpose: "Auditar comandos de criação/atualização de OS para rastreabilidade.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "ServiceOrderCommand";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "service_order_command_log_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador do log de comando de OS.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência à OS afetada.";
                }, {
                    readonly name: "service_order_command_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao comando de OS executado.";
                }, {
                    readonly name: "command_type";
                    readonly type: "varchar(60)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo do comando executado (criação, atualização, fechamento).";
                }, {
                    readonly name: "previous_status";
                    readonly type: "varchar(40)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Status anterior da OS, quando aplicável.";
                }, {
                    readonly name: "new_status";
                    readonly type: "varchar(40)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Novo status da OS, quando aplicável.";
                }, {
                    readonly name: "service_order_total";
                    readonly type: "decimal(12,2)";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Total da OS após o comando.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "varchar(40)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Perfil do usuário que executou o comando.";
                }, {
                    readonly name: "actor_user_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Identificador do usuário executor, quando disponível.";
                }, {
                    readonly name: "occurred_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do comando para auditoria e filtros.";
                }, {
                    readonly name: "status";
                    readonly type: "varchar(30)";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Estado do registro de log (ativo, retido, arquivado).";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora de persistência do log.";
                }];
                readonly primaryKey: readonly ["service_order_command_log_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "service_order_id";
                    readonly targetEntity: "ServiceOrder";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "OS impactada pelo comando.";
                }, {
                    readonly fieldName: "service_order_command_id";
                    readonly targetEntity: "ServiceOrderCommand";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Comando registrado para auditoria.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_soclog_service_order_id";
                    readonly columns: readonly ["service_order_id"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de logs por OS.";
                }, {
                    readonly indexName: "idx_soclog_command_id";
                    readonly columns: readonly ["service_order_command_id"];
                    readonly unique: false;
                    readonly reason: "Rastrear execuções de um comando específico.";
                }, {
                    readonly indexName: "idx_soclog_occurred_at";
                    readonly columns: readonly ["occurred_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por período para auditoria.";
                }, {
                    readonly indexName: "idx_soclog_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Gestão de retenção e arquivamento.";
                }, {
                    readonly indexName: "idx_soclog_new_status";
                    readonly columns: readonly ["new_status"];
                    readonly unique: false;
                    readonly reason: "Auditoria de transições de status.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly reason: "Armazenar payloads e diffs do comando sem impactar consultas principais.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceOrderCommandLog.defs.ts";
                readonly exportName: "serviceOrderCommandLogTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceOrderCommandLogTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_1_external/serviceOrderMetrics.defs" {
    export const serviceOrderMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "serviceOrderMetrics";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 45;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "serviceOrderMetrics";
                readonly tableName: "service_order_metrics";
                readonly moduleId: "repairBay";
                readonly title: "Métricas de Ordens de Serviço";
                readonly purpose: "Acompanhar volume, status e valores das ordens de serviço ao longo do tempo.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_at";
                readonly columns: readonly [{
                    readonly name: "event_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly default: "now()";
                    readonly description: "Data/hora do evento de métrica.";
                }, {
                    readonly name: "service_order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Identificador da OS relacionada ao evento.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Status da OS no momento do evento.";
                }, {
                    readonly name: "actor_role";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Perfil do usuário que executou a ação.";
                }, {
                    readonly name: "vehicle_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Veículo vinculado à OS.";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Quantidade de ordens de serviço.";
                }, {
                    readonly name: "total_value";
                    readonly type: "numeric(14,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total acumulado das OS.";
                }, {
                    readonly name: "labor_total";
                    readonly type: "numeric(14,2)";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Valor total de mão de obra.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "status";
                    readonly column: "status";
                    readonly type: "text";
                    readonly description: "Status da OS no momento do evento.";
                }, {
                    readonly dimensionId: "actorRole";
                    readonly column: "actor_role";
                    readonly type: "text";
                    readonly description: "Perfil do usuário que executou a ação.";
                }, {
                    readonly dimensionId: "vehicleId";
                    readonly column: "vehicle_id";
                    readonly type: "uuid";
                    readonly description: "Veículo vinculado à OS.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "orderCount";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de ordens de serviço.";
                }, {
                    readonly measureId: "totalValue";
                    readonly column: "total_value";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total acumulado das OS.";
                }, {
                    readonly measureId: "laborTotal";
                    readonly column: "labor_total";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Valor total de mão de obra.";
                }];
                readonly sourceWriteEvents: readonly ["createServiceOrder", "updateServiceOrderStatus", "closeServiceOrder", "addLaborItem"];
                readonly hypertable: {
                    readonly timeColumn: "event_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_service_order_metrics_event_at";
                        readonly columns: readonly ["event_at"];
                        readonly purpose: "Acelerar consultas por período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_status_time";
                        readonly columns: readonly ["status", "event_at"];
                        readonly purpose: "Filtrar métricas por status e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_actor_role_time";
                        readonly columns: readonly ["actor_role", "event_at"];
                        readonly purpose: "Filtrar métricas por perfil e período.";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_service_order_metrics_vehicle_time";
                        readonly columns: readonly ["vehicle_id", "event_at"];
                        readonly purpose: "Filtrar métricas por veículo e período.";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/serviceOrderMetrics.defs.ts";
                readonly exportName: "serviceOrderMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default serviceOrderMetricsMetricTableDefinition;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/addLaborItem.defs" {
    export const useCase: {
        readonly usecaseId: "addLaborItem";
        readonly title: "Adicionar mão de obra";
        readonly purpose: "Registrar item de mão de obra e recalcular total da OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["laborItemUsecaseEntity", "serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["laborItemUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "addLaborItem";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "hoursWorked";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "hourlyRate";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "laborItemId";
                readonly type: "string";
            }, {
                readonly name: "serviceOrderTotal";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/addPartToServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "addPartToServiceOrder";
        readonly title: "Adicionar peça à OS";
        readonly purpose: "Registrar peça utilizada, baixar estoque e recalcular total da OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity", "serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Part";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_adjustment_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "addPartToServiceOrder";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "partId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "unitPrice";
                readonly type: "number";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderTotal";
                readonly type: "number";
            }, {
                readonly name: "newStockLevel";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleInventoryLowStock", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/adjustInventory.defs" {
    export const useCase: {
        readonly usecaseId: "adjustInventory";
        readonly title: "Ajustar estoque";
        readonly purpose: "Aplicar ajustes manuais de estoque e registrar o comando.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly outputEntities: readonly ["inventoryAdjustmentCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Part";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "InventoryStock";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_adjustment_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "adjustInventory";
            readonly input: readonly [{
                readonly name: "inventoryStockId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "partId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantityDelta";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "reasonCode";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "newQuantity";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleInventoryLowStock", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/closeServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "closeServiceOrder";
        readonly title: "Fechar OS";
        readonly purpose: "Fechar a OS confirmando total e registrando o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "closeServiceOrder";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleServiceOrderTotal", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/createServiceOrder.defs" {
    export const useCase: {
        readonly usecaseId: "createServiceOrder";
        readonly title: "Criar OS";
        readonly purpose: "Criar uma nova ordem de serviço e registrar o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Customer";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "createServiceOrder";
            readonly input: readonly [{
                readonly name: "customerId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderStatus", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/generateInvoice.defs" {
    export const useCase: {
        readonly usecaseId: "generateInvoice";
        readonly title: "Gerar fatura";
        readonly purpose: "Criar fatura a partir da OS concluída.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "generateInvoice";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
            }, {
                readonly name: "total";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/generateMaintenanceForecast.defs" {
    export const useCase: {
        readonly usecaseId: "generateMaintenanceForecast";
        readonly title: "Gerar manutenção prevista";
        readonly purpose: "Gerar ou atualizar previsões de manutenção com base no histórico.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["maintenanceForecastUsecaseEntity", "maintenanceForecastCommandUsecaseEntity"];
        readonly outputEntities: readonly ["maintenanceForecastUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "maintenance_forecast";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "generateMaintenanceForecast";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "forecastDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "forecastMileageKm";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "forecastType";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "maintenanceForecastId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleMaintenanceForecast", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/requestRepairSuggestion.defs" {
    export const useCase: {
        readonly usecaseId: "requestRepairSuggestion";
        readonly title: "Solicitar sugestão de reparo";
        readonly purpose: "Gerar e armazenar sugestão de reparo via IA para a OS.";
        readonly actor: "mechanic";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["repairSuggestionUsecaseEntity"];
        readonly outputEntities: readonly ["repairSuggestionUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "repair_suggestion";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "requestRepairSuggestion";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "issueDescription";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "repairSuggestionId";
                readonly type: "string";
            }, {
                readonly name: "suggestionStatus";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/updateInvoiceStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateInvoiceStatus";
        readonly title: "Atualizar status da fatura";
        readonly purpose: "Atualizar status de faturamento interno.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateInvoiceStatus";
            readonly input: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "invoiceId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/updateServiceOrderStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateServiceOrderStatus";
        readonly title: "Atualizar status da OS";
        readonly purpose: "Atualizar o status da OS seguindo o ciclo de vida e registrar o comando.";
        readonly actor: "attendant";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly outputEntities: readonly ["serviceOrderCommandUsecaseEntity"];
        readonly readsTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "service_order_command_log";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly commands: readonly [{
            readonly commandId: "updateServiceOrderStatus";
            readonly input: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "newStatus";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly rulesApplied: readonly ["ruleServiceOrderStatus", "ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/viewDashboardMetrics.defs" {
    export const useCase: {
        readonly usecaseId: "viewDashboardMetrics";
        readonly title: "Visualizar dashboard operacional";
        readonly purpose: "Consultar métricas operacionais consolidadas para o painel.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "service_order_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "invoice_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "maintenance_forecast_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "viewDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "openServiceOrders";
                readonly type: "number";
            }, {
                readonly name: "monthlyRevenue";
                readonly type: "number";
            }, {
                readonly name: "upcomingMaintenance";
                readonly type: "number";
            }, {
                readonly name: "lowStockCount";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102044_/l1/repairBay/layer_3_usecases/viewVehicleHistory.defs" {
    export const useCase: {
        readonly usecaseId: "viewVehicleHistory";
        readonly title: "Consultar histórico do veículo";
        readonly purpose: "Consultar histórico completo de serviços, peças e custos por veículo/cliente.";
        readonly actor: "shopOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly [];
        readonly outputEntities: readonly [];
        readonly readsTables: readonly [{
            readonly tableName: "Customer";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Vehicle";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "ServiceOrder";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "Invoice";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "labor_item";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly commands: readonly [{
            readonly commandId: "viewVehicleHistory";
            readonly input: readonly [{
                readonly name: "vehicleId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "customerId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "serviceOrdersCount";
                readonly type: "number";
            }, {
                readonly name: "totalSpent";
                readonly type: "number";
            }];
        }];
        readonly rulesApplied: readonly ["ruleRoleAccess"];
    };
    export default useCase;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102044_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102044_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102044_/l2/repairBay/customerDetail.defs" {
    export const customerDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerDetail";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 58;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerDetail";
                readonly pageName: "Criar ordem de serviço";
                readonly actor: "attendant";
                readonly purpose: "Registrar nova OS com cliente, veículo e itens iniciais.";
                readonly capabilities: readonly ["serviceOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly ["serviceOrderWorkflow"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["serviceOrder", "customer", "vehicle", "partInventory"];
                readonly pageInputs: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do cliente selecionado para a OS.";
                    readonly entityRef: "Customer";
                    readonly fieldRef: "customerId";
                }, {
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do veículo selecionado para a OS.";
                    readonly entityRef: "Vehicle";
                    readonly fieldRef: "vehicleId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "serviceOrderList";
                    readonly trigger: "Ação criar OS";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "serviceOrderDetail";
                    readonly trigger: "OS criada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do cliente e veículo";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "customerVehicleSummary";
                        readonly purpose: "Exibir cliente e veículo selecionados antes da criação da OS.";
                        readonly userActions: readonly ["confirmarSelecao"];
                        readonly requiredEntities: readonly ["Customer", "Vehicle"];
                        readonly readsFields: readonly ["Customer.customerId", "Customer.name", "Customer.phone", "Vehicle.vehicleId", "Vehicle.plate", "Vehicle.model", "Vehicle.year"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Dados iniciais da OS";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderNotesForm";
                        readonly purpose: "Registrar observações iniciais da OS.";
                        readonly userActions: readonly ["preencherObservacoes"];
                        readonly requiredEntities: readonly ["ServiceOrder"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["ServiceOrder.notes"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de criação";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderCreateAction";
                        readonly purpose: "Confirmar criação da OS com cliente e veículo selecionados.";
                        readonly userActions: readonly ["criarOS"];
                        readonly requiredEntities: readonly ["ServiceOrder", "ServiceOrderCommand", "Customer", "Vehicle"];
                        readonly readsFields: readonly ["Customer.customerId", "Vehicle.vehicleId", "ServiceOrder.notes"];
                        readonly writesFields: readonly ["ServiceOrder.serviceOrderId", "ServiceOrder.status", "ServiceOrder.total", "ServiceOrderCommand.serviceOrderCommandId"];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderTotal", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "initServiceOrder";
                readonly purpose: "Criar OS e retornar identificador e status inicial.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["Customer", "Vehicle"];
                readonly writesEntities: readonly ["ServiceOrder", "ServiceOrderCommand"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["service_order_command_log", "service_order_metrics"];
                readonly usecaseRefs: readonly ["createServiceOrder"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleServiceOrderTotal", "ruleRoleAccess"];
            }];
        };
    };
    export default customerDetailPagePlan;
}
declare module "_102044_/l2/repairBay/customerList.defs" {
    export const customerListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 57;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerList";
                readonly pageName: "Dashboard de métricas";
                readonly actor: "shopOwner";
                readonly purpose: "Acompanhar métricas consolidadas do negócio.";
                readonly capabilities: readonly ["dashboardInsights"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "cardsResumoMetricas";
                        readonly purpose: "Exibir indicadores consolidados do negócio.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Detalhamento de métricas";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "tabelaMetricasConsolidadas";
                        readonly purpose: "Apresentar tabelas consolidadas de métricas operacionais.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getMetricDashboard";
                readonly purpose: "Carregar tabelas de métricas";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "openServiceOrders";
                    readonly type: "number";
                }, {
                    readonly name: "monthlyRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "upcomingMaintenance";
                    readonly type: "number";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["service_order_metrics", "inventory_metrics", "invoice_metrics", "maintenance_forecast_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }];
        };
    };
    export default customerListPagePlan;
}
declare module "_102044_/l2/repairBay/serviceOrderList.defs" {
    export const serviceOrderListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "serviceOrderList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 61;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "serviceOrderList";
                readonly pageName: "Gerar fatura";
                readonly actor: "shopOwner";
                readonly purpose: "Selecionar OS e confirmar geração de fatura.";
                readonly capabilities: readonly ["billingManagement"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["billingWorkflow"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["invoice", "serviceOrder"];
                readonly pageInputs: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador da OS selecionada para gerar a fatura.";
                    readonly entityRef: "ServiceOrder";
                    readonly fieldRef: "serviceOrderId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "invoiceList";
                    readonly trigger: "Ação gerar fatura";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "invoiceDetail";
                    readonly trigger: "Fatura gerada";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo da OS";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceOrderSummary";
                        readonly purpose: "Exibir dados essenciais da OS para validação antes da emissão da fatura.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["ServiceOrder"];
                        readonly readsFields: readonly ["serviceOrderId", "status", "total", "customerName", "vehiclePlate", "closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Condições de pagamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "paymentTermsForm";
                        readonly purpose: "Informar condições de pagamento para a fatura.";
                        readonly userActions: readonly ["informPaymentTerms"];
                        readonly requiredEntities: readonly ["Invoice"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["paymentTerms", "dueDate", "paymentMethod"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de emissão";
                    readonly mode: "commit";
                    readonly organisms: readonly [{
                        readonly organismName: "generateInvoiceAction";
                        readonly purpose: "Confirmar geração da fatura vinculada à OS.";
                        readonly userActions: readonly ["generateInvoice"];
                        readonly requiredEntities: readonly ["Invoice", "ServiceOrder", "InvoiceCommand"];
                        readonly readsFields: readonly ["serviceOrderId", "total", "paymentTerms", "dueDate", "paymentMethod"];
                        readonly writesFields: readonly ["invoiceId", "status", "serviceOrderId", "total"];
                        readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getServiceOrderSummaryForInvoice";
                readonly purpose: "Consultar dados resumidos da OS para confirmação de faturamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "vehiclePlate";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["ServiceOrder"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleServiceOrderTotal", "ruleRoleAccess"];
            }, {
                readonly commandName: "createInvoiceFromServiceOrder";
                readonly purpose: "Gerar fatura a partir da OS com condições de pagamento.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "serviceOrderId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "paymentTerms";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "dueDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "paymentMethod";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "total";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["ServiceOrder"];
                readonly writesEntities: readonly ["Invoice", "InvoiceCommand"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly ["invoice_metrics"];
                readonly usecaseRefs: readonly ["generateInvoice"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleInvoiceFromServiceOrder", "ruleRoleAccess"];
            }];
        };
    };
    export default serviceOrderListPagePlan;
}
declare module "_102044_/l2/repairBay/vehicleDetail.defs" {
    export const vehicleDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "vehicleDetail";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 60;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "vehicleDetail";
                readonly pageName: "Detalhe do veículo";
                readonly actor: "attendant";
                readonly purpose: "Cadastrar ou atualizar informações do veículo e vínculo com cliente.";
                readonly capabilities: readonly ["manageVehicles"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["vehicle", "customer"];
                readonly pageInputs: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do veículo para edição.";
                    readonly entityRef: "Vehicle";
                    readonly fieldRef: "Vehicle.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "vehicleList";
                    readonly trigger: "Abrir veículo ou criar novo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "vehicleList";
                    readonly trigger: "Salvar veículo";
                    readonly description: "Retorno após criação/atualização do veículo.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados do veículo";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "VehicleForm";
                        readonly purpose: "Cadastrar ou editar dados do veículo.";
                        readonly userActions: readonly ["preencherDadosVeiculo", "salvarVeiculo"];
                        readonly requiredEntities: readonly ["Vehicle"];
                        readonly readsFields: readonly ["Vehicle.id", "Vehicle.make", "Vehicle.model", "Vehicle.year", "Vehicle.plate", "Vehicle.vin"];
                        readonly writesFields: readonly ["Vehicle.make", "Vehicle.model", "Vehicle.year", "Vehicle.plate", "Vehicle.vin"];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }, {
                    readonly sectionName: "Vínculo com cliente";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "CustomerSelector";
                        readonly purpose: "Selecionar cliente ativo para vínculo do veículo.";
                        readonly userActions: readonly ["buscarCliente", "selecionarCliente"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly ["Customer.id", "Customer.name", "Customer.status"];
                        readonly writesFields: readonly ["Vehicle.customerId"];
                        readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getVehicle";
                readonly purpose: "Carregar dados do veículo para edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "vehicleRef";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                }, {
                    readonly name: "make";
                    readonly type: "string";
                }, {
                    readonly name: "model";
                    readonly type: "string";
                }, {
                    readonly name: "year";
                    readonly type: "number";
                }, {
                    readonly name: "plate";
                    readonly type: "string";
                }, {
                    readonly name: "vin";
                    readonly type: "string";
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "customerStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Vehicle", "Customer"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly commandName: "searchCustomers";
                readonly purpose: "Buscar clientes para seleção de vínculo.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchTerm";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "customerStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }, {
                readonly commandName: "saveVehicle";
                readonly purpose: "Criar ou atualizar veículo com vínculo ao cliente.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "vehicleRef";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "make";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "model";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "year";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "plate";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "vin";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "vehicleId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly ["Vehicle"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleVehicleCustomerLink", "ruleRoleAccess"];
            }];
        };
    };
    export default vehicleDetailPagePlan;
}
declare module "_102044_/l2/repairBay/vehicleList.defs" {
    export const vehicleListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "vehicleList";
        readonly moduleName: "repairBay";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 59;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "vehicleList";
                readonly pageName: "Dashboard operacional";
                readonly actor: "shopOwner";
                readonly purpose: "Visualizar indicadores operacionais do dia a dia.";
                readonly capabilities: readonly ["dashboardInsights"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["maintenanceForecastWorkflow"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo operacional";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "cardsResumoOperacional";
                        readonly purpose: "Exibir indicadores operacionais consolidados.";
                        readonly userActions: readonly ["viewDashboard"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly ["openServiceOrders", "monthlyRevenue", "upcomingMaintenance", "lowStockCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["ruleRoleAccess"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOperationalSummary";
                readonly purpose: "Carregar indicadores operacionais";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "openServiceOrders";
                    readonly type: "number";
                }, {
                    readonly name: "monthlyRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "upcomingMaintenance";
                    readonly type: "number";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["service_order_metrics", "inventory_metrics", "invoice_metrics", "maintenance_forecast_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["ruleRoleAccess"];
            }];
        };
    };
    export default vehicleListPagePlan;
}
